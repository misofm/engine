FAIL — stopped at preflight.

- Required HEAD: `6243f43160701da60dc067a6b17586bb7dd071d1`
- Actual HEAD: `2c865f18fb5aa93cb278ee414bccca60a239a7b9`
- Worktree: clean
- All five required `/tmp` paths: absent
- Steps 1–4: not executed
- Evidence directory: not created due to hard precondition failure