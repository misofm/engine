Execute issue #555 pre-pin qualification steps 1-4 only as Luna HIGH. Be direct: do not narrate extensively, do not create ad-hoc gate frameworks, do not poll your own long-running commands, and do not retry any specified qualification command. Capture evidence under /tmp/issue555-luna-a2. The prior /tmp/issue555-luna-a1 is an interrupted, non-authoritative attempt; do not modify or reuse it.

Read /home/bl/misofm/engine-hex-artifact-qualification/AGENTS.md and .github/ISSUE_SPECS/555-qualify-shared-hex-web-artifact.md fully. Repository is read-only. No Git writes, GitHub operations, repo edits, pin/spec/source edits, Astra launch, repairs, benchmarks, new gates, expectation changes, or legacy/paused-539 inspection. All Git/GitHub belongs to root.

Fixed identities:
- worktree HEAD must be 6243f43160701da60dc067a6b17586bb7dd071d1 and clean
- frozen product source is exactly e4f46fa808e413507d204e81b6a4ebc27254869c
- required Wasm digest is exactly 6452f0db237da1d57b3594e7d95dd53a089a604d5b0791ea8b3533c5930c5a1c; any other digest is an immediate STOP
- baseline is /tmp/issue537-delivery/artifact
- preserve byte-identical copy/hash of /tmp/issue349-partials/543-artifact-job.log and its two recorded failures

Before starting, require all of these absent/nonexistent or STOP: /tmp/issue555-luna-a2, /tmp/issue555-repin-probe-empty, /tmp/issue555-qualified-artifact, /tmp/issue555-native-target, /tmp/issue555-hermetic-target. Then create /tmp/issue555-luna-a2.

Source proof must be finite and efficient. Use read-only `git archive e4f46...` to create two isolated frozen exports under /tmp/issue555-luna-a2: pristine-probe-source and overlay-source. Git archive is the source authority. Record `git ls-tree -r -l` as the canonical complete file inventory and a complete sorted exported path/type/mode/size/SHA-256 manifest. Prove exported regular-file bytes in one bulk `git hash-object --no-filters --stdin-paths` pass against the ordered Git blob OIDs and prove path set plus Git-tracked executable-bit/symlink semantics. Do not treat filesystem umask/default-ACL group-write bits as product changes; Git records only regular/executable/symlink modes. Compare frozen to HEAD and prove all descendant differences are issue/evidence only, not product/config. Do this once, without retries.

For every specified command, create unique `.argv`, `.cwd`, `.env`, `.stdout`, `.stderr`, and `.status` files under /tmp/issue555-luna-a2. Preserve raw streams and true numeric exit status. Record Rust/Cargo/toolchain/config/source IDs. Stop immediately after first nonzero or semantic failure and retain evidence; do not repair or rerun.

Step 1: from pristine-probe-source, first create /tmp/issue555-repin-probe-empty and prove empty/non-symlink. Run exactly:
env MISO_ENGINE_WEB_AUDIOWORKLET_REPIN=1 bash scripts/build-web-audioworklet.sh /tmp/issue555-repin-probe-empty
Require status 0; stdout exactly expected digest plus newline; directory still empty/non-symlink. Write /tmp/issue555-luna-a2/STEP1_CHECKPOINT.md immediately with digest/status/source/capture paths, then continue only if green.

Step 2: overlay-source must initially prove identical to frozen source. Change only hosts/host-web/web/miso-engine-v1-audio-worklet-artifact.sha256 from the old pin to expected digest, lowercase 64 hex plus final newline. Preserve before/after bytes/hashes, exact no-index diff, and proof this is the sole scratch delta. From overlay-source run exactly:
bash scripts/build-web-audioworklet.sh /tmp/issue555-qualified-artifact
Require 0, exact issue-specified six file names and no extras, and independent Wasm hash equal expected. Write /tmp/issue555-luna-a2/ARTIFACT_CHECKPOINT.md immediately with six name/byte-count/SHA-256 rows and capture paths.

Step 3: preserve complete sorted name/byte-count/SHA-256 manifests for candidate and /tmp/issue537-delivery/artifact and explicit per-file equal/different results for all six. Do not classify/explain away deltas; Astra will.

Step 4 from overlay-source, in this exact order and with fresh specified target paths, run only these existing commands:
1. env CARGO_TARGET_DIR=/tmp/issue555-native-target bash scripts/check-capi-abi.sh .
2. bash scripts/check-web-audioworklet.sh /tmp/issue555-qualified-artifact
3. env CARGO_TARGET_DIR=/tmp/issue555-native-target python3 -B scripts/check-browser-expected-resources.py --artifacts /tmp/issue555-qualified-artifact
4. env CARGO_TARGET_DIR=/tmp/issue555-hermetic-target bash scripts/test-web-audioworklet.sh
5. npm --prefix hosts/host-web/qualification ci --ignore-scripts
6. npm --prefix hosts/host-web/qualification run qualify -- --artifacts /tmp/issue555-qualified-artifact --browser all --check-matrix --self-test-mutations
No `--record-matrix`. Require each 0. Require actual selected/executed Chromium, Firefox and WebKit and zero skipped browser selection; semantic absence/skipping is failure even with status 0.

At end prove the repository remains clean/unchanged and committed expected.json, results.json and BROWSER_DEPLOYMENT_MATRIX.md match frozen bytes. Write /tmp/issue555-luna-a2/PREPIN_REPORT.md and return concise PASS/FAIL with exact first failure, checkpoint/capture paths, six-file manifest/delta table, all statuses, browser selected/executed/skipped evidence, and readiness (only on full green) for root checkpoint plus Astra MEDIUM. Do not execute steps 5+.
