# Issue #555 single-command recovery rebrief

## Bounded decision

**PASS for the frozen-source precondition only.** The existing independent Git-identity evidence is sufficient to treat `/tmp/issue555-luna-a3/probe-source` as an export of frozen product source `e4f46fa808e413507d204e81b6a4ebc27254869c` for the sole next repin-probe invocation.

Root's prior audit covers all 8,439 entries: the existing frozen and probe path/blob tables are byte-identical, and the existing type/mode tables have identical Git file types and executable-bit classifications. The differing ordinary writable permission bits that triggered the first temporary failure are not Git source identity and do not defeat this ruling. Inspection also confirms 8,439 rows in each existing table and identical `frozen-path-oids.tsv` / `probe-path-oids.tsv` content. This ruling gives **no artifact, build, ABI, resource, PCM, browser, post-pin, or CI qualification credit**.

Frozen identities remain:

- Product source: `e4f46fa808e413507d204e81b6a4ebc27254869c`
- Orchestration: `2c865f18fb5aa93cb278ee414bccca60a239a7b9`
- Verified export: `/tmp/issue555-luna-a3/probe-source`
- Expected probe digest: `6452f0db237da1d57b3594e7d95dd53a089a604d5b0791ea8b3533c5930c5a1c`

The prior full-permission comparison failure and subsequent `label: unbound variable` failure were temporary inventory/wrapper failures, not specified build-gate failures. Preserve their evidence and the coordinator interruption provenance. Do not delete, rewrite, relabel as PASS, or grant qualification credit to any prior partial. No fourth inventory attempt, harness repair, regenerated identity proof, or new framework is authorized.

## Sole authorized next step

Root may authorize an **actual Luna HIGH** to run the existing repin probe exactly once. Before authorization, `/tmp/issue555-repin-probe-empty` and the three capture files below are absent; this rebrief observed them absent. Luna must use the already-verified export and direct shell commands only: no function, local/dynamic variable, multiphase wrapper, batch script, inventory pass, or other build/gate.

Run these literal commands in one ordinary shell, stopping immediately if either `mkdir` or `cd` fails:

```sh
mkdir -- /tmp/issue555-repin-probe-empty
cd -- /tmp/issue555-luna-a3/probe-source
env MISO_ENGINE_WEB_AUDIOWORKLET_REPIN=1 bash scripts/build-web-audioworklet.sh /tmp/issue555-repin-probe-empty > /tmp/issue555-luna-a3/repin-probe.stdout 2> /tmp/issue555-luna-a3/repin-probe.stderr
printf '%s\n' "$?" > /tmp/issue555-luna-a3/repin-probe.status
```

These are the complete captures for this step:

- stdout: `/tmp/issue555-luna-a3/repin-probe.stdout`
- stderr: `/tmp/issue555-luna-a3/repin-probe.stderr`
- numeric status: `/tmp/issue555-luna-a3/repin-probe.status`

After the status redirect, Luna stops and returns control to root without running any validation, retry, cleanup, repair, overlay, artifact build, or later gate. Root evaluates the retained captures. Success requires status `0`, stdout consisting of the single expected digest line `6452f0db237da1d57b3594e7d95dd53a089a604d5b0791ea8b3533c5930c5a1c`, and `/tmp/issue555-repin-probe-empty` remaining an empty non-symlink directory.

## Finite failure stop

Any setup failure, nonzero probe status, unexpected stderr that indicates failure, stdout mismatch or extra stdout, changed/second digest, nonempty output directory, missing capture, or interruption is a hard stop for root/Sol assessment. It authorizes neither a rerun nor inventory/harness correction and is not authority to accept another digest or edit the pin.

Only after root separately accepts the real probe may execution be rebriefed stepwise. All full artifact, ABI, static/resource, PCM, browser, Astra-before-pin, pin-change, post-pin, and required-CI obligations remain unchanged and deferred; none is authorized by this document.
