You are the single root-authorized Luna HIGH worker for issue #555 pre-pin qualification. Execute original finite steps 1-4 only, then pause for root and Astra MEDIUM. Be concise and action-oriented. Do not redesign the proof, poll your own commands, retry a specified command, or launch parallel long-running commands.

Read completely before acting:
- /home/bl/misofm/engine-hex-artifact-qualification/AGENTS.md
- /home/bl/misofm/engine-hex-artifact-qualification/.github/ISSUE_SPECS/555-qualify-shared-hex-web-artifact.md
- /tmp/issue349-partials/555-root-inventory-stop.json

Binding identities and scope:
- Orchestration worktree and cwd: /home/bl/misofm/engine-hex-artifact-qualification
- Required clean orchestration HEAD: 2c865f18fb5aa93cb278ee414bccca60a239a7b9
- Immutable qualified product source: e4f46fa808e413507d204e81b6a4ebc27254869c
- Expected Wasm digest, exact or STOP: 6452f0db237da1d57b3594e7d95dd53a089a604d5b0791ea8b3533c5930c5a1c
- Baseline artifact: /tmp/issue537-delivery/artifact
- Fresh evidence/capture root: /tmp/issue555-luna-a3
- Preserve a1/a2 exactly and never relabel them PASS. a1 was deliberately root-stopped after repeated inventory rework; a2 stopped only because root's evidence commit changed HEAD.

The repository is read-only. Do not edit source, pin, spec, evidence, or any repository path. No Git mutation, GitHub operation, commit, checkout, worktree, branch, push, issue action, Astra launch, benchmark, expectation update, repair, new gate, or Sol implementation. Scratch exports, provisional scratch pin overlay, target/output directories, dependency installation inside scratch, and raw captures under /tmp are allowed by the issue.

Preflight exactly once. Require clean HEAD above; frozen commit exists; baseline plus both required-run logs `/tmp/issue349-partials/543-artifact-job.log` and `/tmp/issue349-partials/543-policy-job.log` exist; and these paths are all absent/non-symlink before creation: `/tmp/issue555-luna-a3`, `/tmp/issue555-repin-probe-empty`, `/tmp/issue555-qualified-artifact`, `/tmp/issue555-native-target`, `/tmp/issue555-hermetic-target`. Stop on failure. Copy both required-run logs byte-for-byte into evidence and record hashes.

Use this bounded exact-source proof once, not another inventory framework:
1. Record one canonical `git ls-tree -r -l --full-tree` inventory for frozen source.
2. Create two isolated exports (`probe-source`, `overlay-source`) using read-only `git archive e4f46... | tar -x` under `/tmp/issue555-luna-a3`. No `.git`, target, dependencies, or prior outputs.
3. Record one complete sorted exported path/type/executable-bit/size/SHA-256 manifest using bounded `find -print0 | sort -z | xargs -0 sha256sum`/equivalent bulk operations, not a shell process per file.
4. For each export prove tracked path set equals `git ls-tree`; prove all regular-file blob identities in one ordered bulk `git hash-object --no-filters --stdin-paths` pass compared with ordered frozen blob OIDs; handle only actual symlink entries explicitly; compare Git-tracked executable bit and symlink type. Git does not track group/other writable permission bits, so do not fail on umask/default-ACL writable bits.
5. Prove frozen source to orchestration HEAD differs only in `.github/ISSUE_SPECS/**`, `artifacts/issue543-attempt3/**`, and `artifacts/issue555-inventory-stop/**`. Any other product/config delta stops.

For every specified command preserve exact argv, cwd, relevant Rust/Cargo environment and source/config IDs, raw stdout, raw stderr, and true numeric status in uniquely named files under `/tmp/issue555-luna-a3`. A small shell capture function in the one worker invocation is allowed; do not add it to the repo. Do not normalize/truncate streams. Stop at the first concrete specified acceptance failure and retain evidence. Do not repair or rerun.

Step 1 — from exact frozen `probe-source`:
- Create `/tmp/issue555-repin-probe-empty`, prove it is empty and non-symlink.
- Run exactly: `env MISO_ENGINE_WEB_AUDIOWORKLET_REPIN=1 bash scripts/build-web-audioworklet.sh /tmp/issue555-repin-probe-empty`
- Require status 0, stdout exactly expected digest plus newline, retained stderr, and output directory still empty/non-symlink.
- Immediately write `/tmp/issue555-luna-a3/STEP1_CHECKPOINT.md` with source identity, exact digest/status, empty-directory proof, and capture paths. Continue automatically only if green.

Step 2 — in exact frozen `overlay-source`:
- Before overlay prove exact source identity as above.
- Change only `hosts/host-web/web/miso-engine-v1-audio-worklet-artifact.sha256` from the old pin to expected digest, exactly one lowercase 64-hex line with final newline.
- Preserve exact before/after bytes and SHA-256, exact diff, and a proof this is the sole scratch delta.
- Run unchanged ordinary builder exactly: `bash scripts/build-web-audioworklet.sh /tmp/issue555-qualified-artifact`
- Require status 0, independent Wasm digest exactly expected, and exactly these six files with no extras:
  `miso-engine-v1-abi-layout.json`
  `miso-engine-v1-audio-worklet-host.d.ts`
  `miso-engine-v1-audio-worklet-host.js`
  `miso-engine-v1-audio-worklet.js`
  `miso-engine-v1-audio-worklet.simd128.wasm`
  `miso-engine-v1-parameter-metadata.json`
- Immediately write `/tmp/issue555-luna-a3/ARTIFACT_CHECKPOINT.md` with sorted name/byte-count/SHA-256 manifest and builder capture paths. Continue only if green.

Step 3:
- Preserve complete sorted name/byte-count/SHA-256 manifests for candidate and `/tmp/issue537-delivery/artifact`.
- Preserve explicit byte-equal/different result for each of the six names. Do not classify or silently accept deltas; Astra will adjudicate them.

Step 4 — from `overlay-source`, run these existing commands only, in order, exactly once each:
1. `env CARGO_TARGET_DIR=/tmp/issue555-native-target bash scripts/check-capi-abi.sh .`
2. `bash scripts/check-web-audioworklet.sh /tmp/issue555-qualified-artifact`
3. `env CARGO_TARGET_DIR=/tmp/issue555-native-target python3 -B scripts/check-browser-expected-resources.py --artifacts /tmp/issue555-qualified-artifact`
4. `env CARGO_TARGET_DIR=/tmp/issue555-hermetic-target bash scripts/test-web-audioworklet.sh`
5. `npm --prefix hosts/host-web/qualification ci --ignore-scripts`
6. `npm --prefix hosts/host-web/qualification run qualify -- --artifacts /tmp/issue555-qualified-artifact --browser all --check-matrix --self-test-mutations`

Require status 0 for every command and all built-in red controls. Never use `--record-matrix`. The browser gate must show actual selection and execution of Chromium, Firefox, and WebKit with zero skipped browser selection; zero/absent/skipped selection is failure regardless of process status.

Finally prove orchestration worktree remains clean at HEAD `2c865...`; prove repository pin and committed `Cargo.lock`, `rust-toolchain.toml`, `.cargo/config.toml`, `hosts/host-web/tests/browser-v1/expected.json`, `hosts/host-web/qualification/results.json`, and `hosts/host-web/BROWSER_DEPLOYMENT_MATRIX.md` remain byte-identical. Write `/tmp/issue555-luna-a3/PREPIN_REPORT.md`. Return a concise PASS/FAIL report with first failure if any, source/overlay proofs, step checkpoints, six-file manifest/delta table, all command statuses, browser selected/executed/skipped evidence, repository immutability, and exact evidence paths. A PASS means only steps 1-4 are complete and ready for root packaging/Astra MEDIUM; do not perform steps 5+ or edit the pin.
