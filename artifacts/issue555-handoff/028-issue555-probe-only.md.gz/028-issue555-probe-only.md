Repin probe completed and stopped as instructed.

Captures written:

- `/tmp/issue555-luna-a3/repin-probe.stdout`
- `/tmp/issue555-luna-a3/repin-probe.stderr`
- `/tmp/issue555-luna-a3/repin-probe.status`

No validation, readback, retry, cleanup, or further commands performed.