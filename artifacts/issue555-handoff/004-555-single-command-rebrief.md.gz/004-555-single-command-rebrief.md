Wrote the bounded decision to [555-single-command-rebrief.md](/tmp/issue543/555-single-command-rebrief.md).

Decision: existing independent Git identity evidence satisfies the frozen-source precondition only. It authorizes one direct Luna HIGH repin-probe run, with finite failure stop and no fourth inventory repair. No probe/build was launched and no artifact qualification credit was granted.