#!/usr/bin/env bash
set +e
repo=$1
label=$2
shift 2
log=/tmp/issue557/commands.log
raw_dir=/tmp/issue557/raw
mkdir -p /tmp/issue557 "$raw_dir"
head=$(git -C "$repo" rev-parse HEAD 2>&1)
env_snapshot=$(env | LC_ALL=C sort)
printf '%s\n' "--- $label ---" >>"$log"
printf 'argv:' >>"$log"
printf ' %q' "$@" >>"$log"
printf '\ncwd=%q\npre_head=%s\nenvironment:\n%s\n' "$repo" "$head" "$env_snapshot" >>"$log"
stdout_file=$(mktemp)
stderr_file=$(mktemp)
(cd "$repo" && "$@") >"$stdout_file" 2>"$stderr_file"
status=$?
cp "$stdout_file" "$raw_dir/$label.stdout"
cp "$stderr_file" "$raw_dir/$label.stderr"
printf 'status=%s\nstdout:\n' "$status" >>"$log"
printf 'raw_stdout=%s\nraw_stderr=%s\n' "$raw_dir/$label.stdout" "$raw_dir/$label.stderr" >>"$log"
sed -n '1,2000p' "$stdout_file" >>"$log"
printf 'stderr:\n' >>"$log"
sed -n '1,2000p' "$stderr_file" >>"$log"
printf '\n' >>"$log"
cat "$stdout_file"
cat "$stderr_file" >&2
rm -f "$stdout_file" "$stderr_file"
exit "$status"
