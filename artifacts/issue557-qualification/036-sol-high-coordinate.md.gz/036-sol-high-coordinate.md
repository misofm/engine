# Issue #557 Sol HIGH coordination record

## Verdict and frozen identity

Issue #557 attempt 1 is a coherent candidate ready for root evidence packaging and exact-head Sol XHIGH review. The source implementation and every finite local gate in the issue are green. No benchmark or timed workload ran.

- Original synchronized source baseline: `30f658ee1c0c7d86002f5f2fea075a5dfa8a7c2c`
- Numbered issue baseline and Luna implementation start: `780149c661ba7b42f8c1b1d34ad34883b549cd21`
- Root exact-path implementation checkpoint: `ffebeabc05f8a2b793b434eb6a449e230eded282`
- Root spec-EOF correction and final qualification head: `f0ec00ea3dea9a04c8a41cec78bb1795a42de4d4`
- Worktree: `/home/bl/misofm/engine-shared-host-facts`
- Final worktree state: clean

Root corrected only the numbered issue spec's extra terminal blank line between `ffebeabc` and `f0ec00ea`; the five implementation paths and their hashes did not change.

## Actual worker routing

Sol HIGH coordinated actual Luna HIGH through the collaboration agent `/root/partial_cp20/issue557_luna1`. The worker was launched with the explicit collaboration model override `gpt-5.6-luna` and reasoning effort `high`, then resumed through `collaboration.followup_task` after root checkpointed the first tranche. This was collaboration routing, so there is no worker CLI launcher argv to claim or reconstruct. The worker made no commits, pushes, issue edits, or other Git/GitHub mutations.

## Exact implementation paths and final SHA-256

```text
ce41772fbe000cb5325752934a1dfa5720e4a5a4e34d8188e6183ff2d56c2c63  tools/bench-support/src/sysinfo.rs
c992a9244473b21b28f973d46e5c35e6d22c19de603db83415418b5399d11701  tools/bench/src/session.rs
aee723e773ef85bb73d855a786f3289072e4f0d9fb0472a21a5b7df1c597ca69  tools/bench/src/conformance.rs
2cce4135626f58239f3b68aa51eae213469bb4fed07a9f0ea4d4c3e136c462e5  scripts/check-bench-policy.sh
562c9e7166c7b73dd772c4fc49884a95c96639bf0d895c18bbdd9c88644ddb7f  scripts/test-bench-policy.sh
```

The final numbered spec SHA-256 after root's formatting-only correction is:

```text
cbea2c3f4d979414a834c7cbffae3a2e9d518c6c639f6885ea5e9878171ddf67  .github/ISSUE_SPECS/557-shared-session-conformance-host-facts.md
```

## Final gate results

The first focused tranche passed at the uncommitted source state later checkpointed exactly as `ffebeabc`:

- `CARGO_TARGET_DIR=/tmp/issue557-target cargo test --locked -p bench-support sysinfo::tests`: status 0, 10 tests passed.
- Exact `session::tests::shared_host_toolchain_facts_preserve_session_projection`: status 0.
- Exact `conformance::tests::shared_host_toolchain_facts_preserve_conformance_projection`: status 0.
- `bash scripts/check-bench-policy.sh`: status 0.
- `bash scripts/test-bench-policy.sh`: status 0, including both #557 directed mutations.
- `cargo fmt --all -- --check`: status 0.
- Working-tree `git diff --check`: status 0.

After root committed and pushed `ffebeabc`, source stayed frozen and the remaining gates passed:

- `CARGO_TARGET_DIR=/tmp/issue557-target cargo test --locked -p bench --bin bench`: status 0, 37 tests passed.
- `CARGO_TARGET_DIR=/tmp/issue557-target cargo clippy --locked -p bench-support -p bench --all-targets -- -D warnings`: status 0.
- `bash scripts/check-workspace-policy.sh`: status 0.
- Corrected semantic census: status 0. Both subjects delegate to `HostToolchainFacts::gather()`, neither retains a forbidden common acquisition spelling, and graph, protocol, rack, builtins, effect-interchange, and effect-contract remain recorded TOOL9 residuals.
- `git diff --check HEAD^ HEAD` at `ffebeabc`: status 0.
- Final `git diff --check 30f658ee1c0c7d86002f5f2fea075a5dfa8a7c2c...HEAD` at `f0ec00ea`: status 0.

Already-green focused tests were not rerun after the source-freezing checkpoint. Root reran only the original-base committed diff check after fixing the spec EOF.

## Preserved failures and corrections

All preliminary failures remain candidly recorded in `/tmp/issue557/commands.log`:

- Initial `cargo fmt --all -- --check`: status 1 due ordinary Rust formatting differences; formatting was applied and the final check passed.
- First sysinfo test attempt: status 101 due two invalid `bench_support` self-references and an `Option`/`Result` mismatch in the new code. The bounded implementation correction removed these compile errors.
- Second sysinfo test attempt: status 101 because the public fields lacked required documentation. The fields were documented and the final 10-test run passed.
- Initial semantic census: its shell wrapper reported status 0 even though its use of invalid `rg -E` emitted errors. It is not treated as evidence. The corrected census has separate zero-length stderr and passed.
- First original-base committed diff check at `ffebeabc`: status 2 because `.github/ISSUE_SPECS/557-shared-session-conformance-host-facts.md:132` had a new blank line at EOF. Root removed only that blank line, checkpointed `f0ec00ea`, and the one targeted rerun passed.

No source change followed the first coherent checkpoint. No gate was weakened, and no failed output was overwritten.

## Evidence paths

The first tranche's historical capture is `/tmp/issue557/commands.log`. It preserves argv, cwd, pre-command HEAD, environment, statuses, and labelled stdout/stderr sections in one combined log. It is not represented as a pair of independent raw stream files. Supporting first-tranche identity files are:

- `/tmp/issue557/source-sha256.final`
- `/tmp/issue557/source-sha256.final.copy`
- `/tmp/issue557/root-checkpoint-comment.md`
- `/tmp/issue557/run-command.sh`

The resumed qualification used separate raw streams under `/tmp/issue557/raw/`:

- `remaining-bench-test.stdout`, `remaining-bench-test.stderr`
- `remaining-clippy.stdout`, `remaining-clippy.stderr`
- `remaining-workspace-policy.stdout`, `remaining-workspace-policy.stderr`
- `semantic-census.stdout`, `semantic-census.stderr` — preserved invalid `rg -E` attempt
- `semantic-census-corrected.stdout`, `semantic-census-corrected.stderr` — accepted census
- `checkpoint-lineage.stdout`, `checkpoint-lineage.stderr`
- `committed-range-diff-check.stdout`, `committed-range-diff-check.stderr` — preserved spec-EOF failure
- `checkpoint-parent-diff-check.stdout`, `checkpoint-parent-diff-check.stderr`
- `current-status.stdout`, `current-status.stderr`
- `changed-paths.stdout`, `changed-paths.stderr`
- `checkpoint-changed-paths.stdout`, `checkpoint-changed-paths.stderr`
- `current-head.stdout`, `current-head.stderr`
- `current-head-sha256.stdout`, `current-head-sha256.stderr`
- `inspect-spec-tail.stdout`, `inspect-spec-tail.stderr`
- `evidence-files.stdout`, `evidence-files.stderr`
- `root-corrected-committed-range.stdout`, `root-corrected-committed-range.stderr`, `root-corrected-committed-range.status`, `root-corrected-committed-range.argv` — accepted final original-base diff check

For the resumed worker commands, the exact argv, cwd, pre-command identity, environment, and status also remain in `/tmp/issue557/commands.log`; the `.stdout` and `.stderr` files above are the authoritative separate raw byte streams. Root's final targeted check records its exact argv and status in the named `.argv` and `.status` files.

## Review handoff

Exact-head Sol XHIGH should review `f0ec00ea3dea9a04c8a41cec78bb1795a42de4d4` against issue #557. The review should concentrate on unavailable and empty-value fallback behavior, the deliberately different CPU parsers, local runtime/git/timestamp and missing-list ownership, exact record projections, policy mutation sensitivity, and the absence of changes beyond the five implementation paths plus the numbered spec/evidence owned by root. TOOL9 remains partial after this slice.
