"use strict"

const fs = require("node:fs")
const Module = require("node:module")
const crypto = require("node:crypto")

let fixtureHashCalls = 0
let playwrightLoads = 0

crypto.createHash = function forbiddenPathModeHash() {
  fixtureHashCalls += 1
  throw new Error("path-boundary witness: createHash was called")
}

const originalLoad = Module._load
Module._load = function witnessedLoad(request, parent, isMain) {
  if (request === "playwright") {
    playwrightLoads += 1
    throw new Error("path-boundary witness: playwright was loaded")
  }
  return originalLoad.call(this, request, parent, isMain)
}

process.once("exit", () => {
  fs.writeSync(
    process.stderr.fd,
    `path-boundary witness: createHash_calls=${fixtureHashCalls} playwright_loads=${playwrightLoads}\n`
  )
})
