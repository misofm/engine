You are the actual Luna HIGH source reviser for bounded issue #546 attempt 2 in
/home/bl/misofm/engine-operator-live-paths. Read AGENTS.md, the full
.github/ISSUE_SPECS/546-repair-live-operator-paths.md, and
artifacts/issue546-review/sol-xhigh-attempt1.md before acting.

Root has pushed 855495188ae505f4bde17a8c3e423a1779714719 preserving the attempt-1 FAIL.
Fix only the blocking source defect in
scripts/operator/run-stem-store-browser-evals.cjs: fixture/digest preparation currently happens at
module load before --path-self-test dispatch. Defer that preparation behind browser-mode dispatch
so path-only mode performs no fixture hashing. Preserve the browser fixture bytes and digest
contract exactly. Also preserve lazy Playwright loading and all existing browser behavior.

Make the smallest clear source-only revision with apply_patch. Do not edit any other repository
path. Do not add a framework or persistent instrumentation. Do not run browsers, package installs,
benchmarks, fixture generation, Rust gates, qualification, or any verifier. Do not write Git or
GitHub state. You may inspect files and may run only node --check on the changed source after the
edit. Stop after one coherent revision and report the exact changed path plus the source change and
any check you ran. The Sol coordinator will capture the proportional witness, existing gate,
negative controls, restoration, and final evidence.
