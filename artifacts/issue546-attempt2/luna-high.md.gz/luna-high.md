Revised only:

[scripts/operator/run-stem-store-browser-evals.cjs](/home/bl/misofm/engine-operator-live-paths/scripts/operator/run-stem-store-browser-evals.cjs)

Source change: deferred fixture byte generation and SHA-256 digest preparation into browser-mode dispatch; passed the digest into `probe`. Path self-test now performs no fixture hashing or Playwright loading. Browser behavior and fixture contract are unchanged.

Check run: `node --check scripts/operator/run-stem-store-browser-evals.cjs` — passed.