#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

if len(sys.argv) < 4 or sys.argv[2] != "--":
    raise SystemExit("usage: capture.py NAME -- COMMAND [ARG ...]")

name = sys.argv[1]
argv = sys.argv[3:]
root = Path("/tmp/issue546/attempt2")
cwd = Path.cwd()

def identity(token):
    resolved = shutil.which(token) if "/" not in token else str(Path(token).resolve())
    item = {"token": token, "resolved": resolved}
    if resolved and Path(resolved).is_file():
        data = Path(resolved).read_bytes()
        item.update({"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    return item

metadata = {
    "argv": argv,
    "cwd": str(cwd),
    "precommand_identities": [identity(argv[0])],
}
if argv[0] in ("python", "python3") and len(argv) > 1:
    metadata["precommand_identities"].append(identity(argv[1]))
(root / f"{name}.command.json").write_text(json.dumps(metadata, indent=2) + "\n")
with (root / f"{name}.stdout").open("wb") as stdout, (root / f"{name}.stderr").open("wb") as stderr:
    completed = subprocess.run(argv, cwd=cwd, stdout=stdout, stderr=stderr)
(root / f"{name}.status").write_text(f"{completed.returncode}\n")
raise SystemExit(completed.returncode)
