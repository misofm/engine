You are the actual Luna HIGH implementation worker for issue #543 counted attempt 3 in `/home/bl/misofm/engine-shared-hex-authority`.

Read `/home/bl/misofm/engine/AGENTS.md`, the current `.github/ISSUE_SPECS/543-shared-hex-authority.md`, and `/tmp/issue543/attempt3-scope-amendment.md`. Verify the worktree is clean and HEAD is exactly `758cd3e772b4f45d4952e3e5ca0f5ae1434c1036` before editing. If either condition differs, stop and report it.

Implement only the approved three-path correction, using `apply_patch` for every file edit:

1. `tools/native-pcm-runner/Cargo.toml`: replace the direct `[dev-dependencies]` `engine.workspace = true` entry with `bench-support.workspace = true`. Do not alter `serde_json` or the four normal dependencies.
2. `tools/native-pcm-runner/src/lib.rs`: in the test-local `hex_digest` only, replace `engine::hex_lower(&digest)` with `bench_support::digest::hex(&digest)`.
3. `Cargo.lock`: in the `native-pcm-runner` package dependency list only, replace `engine` with `bench-support`, retaining Cargo's ordering. Do not change any version, checksum, or other package entry.

Do not edit the issue spec, artifacts, checker scripts, policy tests, bench-support, any fixture/pin, any other manifest or source, or any JS/TS path. Do not perform Git or GitHub mutations: no add, commit, push, reset, checkout, branch, issue, or PR command. Do not build artifacts, run browsers, install packages, repin, benchmark, or run a broad workspace suite.

After editing, first inspect the exact diff and stop if it contains any other path/hunk. Then run the finite focused gates once on the same source candidate with `CARGO_TARGET_DIR=/tmp/issue543-target`. Preserve every command's exact argv, cwd, pre-command HEAD, pre-command `git status --short`, SHA-256 of the three allowed source files, raw stdout, raw stderr, and numeric status under the unique directory `/tmp/issue543/attempt3-luna-gates`. Do not add these captures to Git. Use distinct numbered files and preserve failures. Stop on the first nonzero status; do not repair outside the three-path scope.

Run:

1. `cargo tree --locked -p native-pcm-runner --edges normal --depth 1`
2. `cargo tree --locked -p native-pcm-runner --edges normal,dev --depth 2`
3. `cargo test --locked -p bench-support digest::tests`
4. `cargo test --locked -p native-pcm-runner`
5. `cargo clippy --locked -p native-pcm-runner --all-targets -- -D warnings`
6. `bash scripts/check-native-pcm-runner.sh . all`
7. `bash scripts/test-native-pcm-runner-v1-policy.sh`
8. `bash scripts/test-native-pcm-runner-portability-v1-policy.sh`
9. `cargo fmt --all -- --check`
10. `bash scripts/check-workspace-policy.sh`
11. A read-only semantic/authority inspection proving `native-pcm-runner` delegates to `bench_support::digest::hex`, that adapter delegates to `engine::hex_lower`, and no raw lowercase byte encoder was introduced in the runner.
12. `git diff --check`

For the two `cargo tree` records, explicitly assess in the terminal report that normal direct dependencies remain exactly `capi`, `session`, `sha2`, and `source`; `bench-support` is dev-only; and no dependency cycle appears. For the final report, include actual model/effort if visible, start/end HEAD and status, exact changed paths and line-level intent, every gate status, capture directory, and any failure. Leave the coherent green working tree uncommitted and pause for root's checkpoint.
