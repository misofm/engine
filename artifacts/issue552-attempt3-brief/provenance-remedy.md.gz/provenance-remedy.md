# Issue #552 provenance and stem-store pin assessment

## Preserved provenance finding

The initial eight-path implementation is actual Luna HIGH work. `/tmp/issue552/luna-attempt1.command.json` records `gpt-5.6-luna` with `model_reasoning_effort="high"`; the worker stopped with uncommitted changes, and root committed them as `c1c591239f30b080566ebcd2d7708caaa44a5bbd`.

The subsequent strict-TypeScript correction is not Luna implementation. The coordinator record and #552 spec explicitly call the change “Sol's bounded attempt-2 revision.” Commit `a5b7c298539fcd3da8f5e497579d5d08b5f5337a` changes `sdk/src/core/hex.ts` from unchecked string indexing to bounded `charAt` access. The retained `/tmp/issue552/attempt2-commit.txt` and `attempt2-push.txt` show that the coordinating turn performed the commit and push even though root exclusively owns Git/GitHub operations.

Do not relabel, squash away, amend, or rewrite this provenance. The pushed history and reports remain candid evidence of a process violation. The one-line correction may be technically useful input, but it cannot be credited as the required Luna HIGH implementation revision or as root-owned delivery.

## Bounded provenance remedy

Do not manufacture authorship with a no-op commit, and do not revert/reapply on top of the same delivery branch merely to change labels. Preserve the existing branch/history as stopped technical input.

For a compliant next attempt, root should provision a fresh issue worktree/branch from the clean Luna checkpoint `c1c591239f30b080566ebcd2d7708caaa44a5bbd` plus any delivered prerequisite merges that do not alter the eight #552 paths. A fresh actual Luna HIGH worker must independently inspect the strict type failure and implement the bounded correction. Root then audits and owns the exact-path commit and push. The worker and coordinator perform no Git/GitHub mutation. This yields a reviewable implementation lineage without rewriting the existing evidence.

The new attempt should preserve the earlier Luna implementation bytes unless the worker identifies a bounded defect, and it must retain the actual prior Sol/Git violation in the issue decision record. Attempt counting must be explicit: attempt 1 is the original Luna implementation; the Sol-authored line is an invalid process correction and technical input; the fresh Luna correction is the next compliant implementation attempt under the remaining three-attempt budget. Sol XHIGH reviews only after root freezes that candidate.

## Stem-store source-provenance gate

`/tmp/issue552/gate02-final.raw.log` is a real required-gate failure. The unchanged gate first reports the delivered operator path self-test PASS, then rejects the changed `incremental-sha256.js` source identity:

```text
actual   e4519729bc0fede4f4ffd815492f7bb22b97c10d0899c05eb1f63e156f5b0e40
expected f53dbc35f891c6f1215397614b3588601bb85895d461a24ac266e93c799626d0
```

The source change is the authorized import plus delegation from the local formatter body to `hexLower(this.digest())`. Existing SHA-256 vectors pass, but they do not satisfy this separate provenance requirement. The pin is a source-identity evidence record, not an output/corpus digest, and a deliberate source edit must either update that evidence through an expressly authorized scope amendment or remain blocked.

There is no permission in this assessment to change the pin or weaken/bypass the gate. Do not edit `scripts/check-stem-store-v1.mjs`, omit gate 2, restore a duplicate encoder to recover the old hash, or claim the passing behavioral vectors supersede provenance.

Changing only that one `sha256` field would be insufficient. The former `incremental-sha256.js` was self-contained; the new file imports `../hex-lower.js`, so its behavior now depends on a second executable source. Pinning only the importing file would let the helper body change while the “repository-owned independent JavaScript implementation” provenance gate remained green. The current provenance shape has only one `artifact`/`sha256` pair and therefore cannot describe the new implementation closure.

The smallest future scope ruling is to amend #552 explicitly before implementation to add exactly these evidence paths:

- `hosts/host-web/web/stem-store/incremental-sha256.provenance.json`;
- `scripts/check-stem-store-v1.mjs`, limited to closing this provenance dependency set.

The amended provenance must retain the primary `artifact` and its source hash, and name exactly one imported dependency, `../hex-lower.js`, with its independently computed source hash. On the current frozen candidate those observed identities are:

- `incremental-sha256.js`: `e4519729bc0fede4f4ffd815492f7bb22b97c10d0899c05eb1f63e156f5b0e40`;
- `../hex-lower.js`: `1eb5564599b0ae99ca404f0c139c0eb9abfe48d488bc55a4bad0b9aacd039560`.

The checker must continue verifying the primary file and additionally require the exact one-entry dependency roster and verify that helper's bytes. A missing, extra, renamed, or hash-mismatched dependency must fail. Preserve `algorithmAuthority`, `implementation`, and `reason`; change the schema only as required to make the new closure explicit. Add a bounded negative proof that mutating either pinned file or the dependency roster fails the same unchanged semantic requirement. Then run the full unchanged `node scripts/check-stem-store-v1.mjs` behavior suite. This strengthens the evidence to cover the implementation closure; it is not a product-output repin or gate relaxation.

Because this expands into a checker path that #552 originally froze after delivered #546, root must approve and synchronize the exact amendment or number a tiny evidence successor before any worker edit. Use actual Luna HIGH for that authorized implementation. Until then #552 remains blocked, both provenance files and the checker are read-only, and neither observed new hash is permission to update a pin.

The final #552 review also waits until delivered #543 is integrated through its own workflow so the frozen cross-language census evaluates the complete Rust and JS/TS state without importing Rust changes into #552's implementation ownership.
