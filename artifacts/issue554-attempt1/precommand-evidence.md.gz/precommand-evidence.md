# Issue 554 pre-command evidence

Working directory: `/home/bl/misofm/engine-benchmark-percentile-summary`

## HEAD

Command:

```text
git rev-parse HEAD
```

Status: `0`

Stdout:

```text
6f5ab4c970d3fd27d0a10f94b30c4cd6421a2563
```

Stderr: empty.

## Status

Command:

```text
git status --short --branch
```

Status: `0`

Stdout:

```text
## codex/benchmark-percentile-summary...origin/codex/benchmark-percentile-summary
```

Stderr: empty.

## Allowed source identities

Command:

```text
sha256sum tools/bench-support/src/stats.rs tools/bench/src/rack.rs tools/bench/src/builtins.rs scripts/check-bench-policy.sh scripts/test-bench-policy.sh
```

Status: `0`

Stdout:

```text
0a41c3f3ad94a9bdc3672e790591993bb60835fd46e105e876172d0d598640cb  tools/bench-support/src/stats.rs
bdde34249166ec78838b2d5207ac711710c35d90f2a267da54a70473a1a5f648  tools/bench/src/rack.rs
455e7c97e8c338f6c925860f9196d4a7df8b6e4508d1e07e93258535440c422c  tools/bench/src/builtins.rs
5e162e78fc8055483944644db7a2a6de1f9f59493880209e1cdbf0edcbda5118  scripts/check-bench-policy.sh
7d5072478ee8485c158e2f7b4f9a810c5f68c0a34c68244c94f0e3fd4cfb6b4a  scripts/test-bench-policy.sh
```

Stderr: empty.
