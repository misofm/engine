Completed all six frozen gates once; all passed.

- `CARGO_TARGET_DIR=/tmp/issue554-target cargo test --locked -p bench --bin bench` — status 0; 35 passed.
- `CARGO_TARGET_DIR=/tmp/issue554-target cargo clippy --locked -p bench-support -p bench --all-targets -- -D warnings` — status 0.
- `rg ... Percentiles ...` — status 0; only `tools/bench-support/src/stats.rs:39`.
- `rg ... p99_9 ...` — status 0; both required field spellings found.
- `cargo fmt --all -- --check` — status 0; no output.
- `git diff --check` — status 0; no output.

Provenance:

```text
HEAD: 86087ab13554410bf773fef204cee9bda6acd37b
## codex/benchmark-percentile-summary...origin/codex/benchmark-percentile-summary
```

No mutations were made. Pausing for root’s evidence checkpoint before Sol xhigh review.