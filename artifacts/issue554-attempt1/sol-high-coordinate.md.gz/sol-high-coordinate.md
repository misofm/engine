# Issue 554 Sol high attempt-1 coordination

## Identity and launcher

- Worktree: `/home/bl/misofm/engine-benchmark-percentile-summary`
- Starting/current uncommitted HEAD: `6f5ab4c970d3fd27d0a10f94b30c4cd6421a2563`
- Actual launcher status: `0`
- Actual model argv, recorded before launch: `-m gpt-5.6-luna -c model_reasoning_effort="high"`
- Raw launcher evidence: `luna-high-attempt1.command.json`, `.stdout`, `.stderr`, `.status`, and `.md` in this directory.

## Preserved failures

1. Luna's first combined guidance/spec read exited `2` because the prompt guessed `.github/ISSUE_SPECS/554-share-the-complete-benchmark-percentile-summary.md`; the actual numbered file is `554-shared-benchmark-percentile-summary.md`. Luna discovered that exact path and read it completely before inspection or editing. The raw failure and corrective read are retained in `luna-high-attempt1.stderr`.
2. The first `cargo fmt --all -- --check` exited `1` only because the newly added short-sample tuple assertion needed rustfmt line wrapping. Luna ran the formatter, retained that failure in the raw transcript, and reran the affected focused builtins test plus formatting and diff checks successfully. No semantic source was changed by that correction.

## Changed-path audit

Exactly the five authorized paths are modified:

```text
scripts/check-bench-policy.sh
scripts/test-bench-policy.sh
tools/bench-support/src/stats.rs
tools/bench/src/builtins.rs
tools/bench/src/rack.rs
```

Current hashes:

```text
f89363e9b5ccf813bf26a4a6058dcec83a9e825b641d60c55b66b2ec2a5c4b47  tools/bench-support/src/stats.rs
b3f7ee1dcdf0f006d3c557c26db29f496ca15847a6c3cd226f4b7a95d366e92f  tools/bench/src/rack.rs
99200cdbb362afc8e2d5389779accd6f11412f911dea903a5278b5343b4586fc  tools/bench/src/builtins.rs
c50674d304b006bf84ebc105391b921557b414662de7e6fa1d67f498ab271215  scripts/check-bench-policy.sh
e7f14747776896126017c3389a5aa625f97c6abb9dea8dcc5bddb14c01ebcd0f  scripts/test-bench-policy.sh
```

Diff size: 40 insertions, 58 deletions. `tools/bench-support` adds `p999` and two summary tests; rack and builtins delete their local summaries and import the shared one; rack retains its exact cardinality assertion at the record seam; builtins pins the existing six adjacent JSON fields; the existing policy gains a sole-summary-owner pattern and one red mutation.

No metadata collection/projection, JSON field construction, schema version, unit, digest/hash operation, fixture, workload, timed closure, package, dependency, or issue-spec path changed.

## Focused gate record

Each command and its complete stdout/stderr is retained in `luna-high-attempt1.stderr`; the entries below preserve the final statuses and essential output without replacing the raw record.

| Command | Final status | Result |
| --- | ---: | --- |
| `CARGO_TARGET_DIR=/tmp/issue554-target cargo test --locked -p bench-support` | 0 | 31 passed, 0 failed |
| `CARGO_TARGET_DIR=/tmp/issue554-target cargo test --locked -p bench --bin bench rack::tests::nearest_rank_uses_the_frozen_one_thousand_observation_indices -- --exact` | 0 | 1 passed, 34 filtered |
| `CARGO_TARGET_DIR=/tmp/issue554-target cargo test --locked -p bench --bin bench builtins::tests::issue035_record_has_exact_render_identity_shape_and_typed_missing_metadata -- --exact` | 0 | 1 passed, 34 filtered; rerun after formatting also status 0 |
| `bash scripts/check-bench-policy.sh` | 0 | `bench policy: ok (1 allocator, 1 escaper, 1 percentile, 1 digest sink, 6 unsafe owners, 3 subjects on the shared timer)` |
| `bash scripts/test-bench-policy.sh` | 0 | `bench policy mutations: ok`; includes `second-percentile-summary-owner` |
| first `cargo fmt --all -- --check` | 1 | retained formatting diff for the new short-sample assertion |
| corrected `cargo fmt --all -- --check` | 0 | pass; final rerun status 0 |
| `git diff --check` | 0 | empty output; final rerun status 0 |

The full bench unit suite, clippy, any benchmark runner, and every timed workload remain unrun, as required before root's focused checkpoint.

## Coordination decision

The single coherent implementation tranche is focused-green and paused. Root should now perform the required exact-path status/commit/upstream audit and checkpoint these five paths before authorizing broader gates or Sol xhigh review. This is not a verifier verdict and does not close issue #554 or TOOL9.
