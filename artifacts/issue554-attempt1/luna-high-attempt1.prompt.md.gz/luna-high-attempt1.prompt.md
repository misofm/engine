You are the mandated Luna HIGH implementer for issue #554 in `/home/bl/misofm/engine-benchmark-percentile-summary`, branch `codex/benchmark-percentile-summary`, exact starting HEAD `6f5ab4c970d3fd27d0a10f94b30c4cd6421a2563`. Read `AGENTS.md` completely and `.github/ISSUE_SPECS/554-share-the-complete-benchmark-percentile-summary.md` completely before acting. Never inspect any legacy engine.

Implement attempt 1 exactly within these five allowed paths only:

- `tools/bench-support/src/stats.rs`
- `tools/bench/src/rack.rs`
- `tools/bench/src/builtins.rs`
- `scripts/check-bench-policy.sh`
- `scripts/test-bench-policy.sh`

Required outcome:

1. Add public `p999: u64` to the existing shared `bench_support::stats::Percentiles`, computed by the existing shared nearest-rank law at `999/1000`.
2. Add shared stats unit coverage for the complete tuple on `1..=1000`, an unsorted short sample, and the existing empty-input panic.
3. Import and use the shared `Percentiles` in rack and builtins; delete their local `Percentiles` structs/implementations.
4. Keep rack's exact `samples.len() == OBSERVATIONS` assertion immediately outside/before shared summary construction. Preserve builtins' acceptance of any nonempty sample.
5. Strengthen the existing pure builtins synthetic-record test to pin exact `min_ns`, `p50_ns`, `p95_ns`, `p99_ns`, `p99_9_ns`, and `max_ns` values and spellings.
6. Extend the existing checker narrowly so `tools/bench-support/src/stats.rs` is the sole `Percentiles` summary owner under `tools/`; add one checker self-test mutation that reintroduces a local `Percentiles` owner and proves the intended failure. Do not redesign the checker.

Freeze every JSON key/order/value/representation, schema version, unit, metadata rule/fallback, hash input/ownership, fixture, workload, observation/warmup/measurement count, audit scope, and timed closure. Do not touch metadata collection or record formatting beyond replacing the percentile summary value source. Do not add a package, dependency, framework, artifact, or benchmark. Do not launch any benchmark or timed workload. Do not edit the issue spec or any other path. Do not use Git.

Use `apply_patch` for source edits. Use `CARGO_TARGET_DIR=/tmp/issue554-target` and `--locked` for Cargo. After implementation, run only the focused tranche gates below, preserving any failures in your response rather than hiding or retrying them:

- `cargo test --locked -p bench-support`
- exact rack percentile test
- exact strengthened builtins record test
- `bash scripts/check-bench-policy.sh`
- `bash scripts/test-bench-policy.sh`
- `cargo fmt --all -- --check`
- `git diff --check`

Do not run the full bench test suite or clippy yet; root requires a checkpoint immediately once this coherent focused tranche is green. Stop and report the exact changed paths, commands/statuses, and any material caveat. Root owns the checkpoint/push and Sol xhigh review; do not launch a verifier.
