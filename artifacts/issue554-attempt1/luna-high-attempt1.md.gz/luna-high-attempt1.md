Implemented attempt 1 in exactly the five allowed paths:

- `tools/bench-support/src/stats.rs`
- `tools/bench/src/rack.rs`
- `tools/bench/src/builtins.rs`
- `scripts/check-bench-policy.sh`
- `scripts/test-bench-policy.sh`

Results:

- bench-support tests: PASS, 31 tests
- exact rack percentile test: PASS
- exact builtins record test: PASS
- benchmark policy checker: PASS
- policy self-tests, including local `Percentiles` mutation: PASS
- `cargo fmt --all -- --check`: PASS after correcting one formatting-only issue
- `git diff --check`: PASS

No full bench suite, clippy, benchmark, or timed workload was run. No checkpoint, push, issue-spec edit, or Git state mutation was performed; root owns those steps.