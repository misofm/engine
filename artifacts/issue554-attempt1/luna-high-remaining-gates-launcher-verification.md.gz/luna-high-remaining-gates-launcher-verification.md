# Remaining-gates Luna launcher verification

Verified launcher `/tmp/issue539/luna-fresh.py` SHA-256:

```text
570ded42a60b51e2cfa0b4dc522c5e4dfa40a893325faaa4a15560c8b648e0d7
```

Invocation:

```text
python3 /tmp/issue539/luna-fresh.py /tmp/issue554/luna-high-remaining-gates /tmp/issue554/luna-high-remaining-gates.prompt.md high /home/bl/misofm/engine-benchmark-percentile-summary
```

Expected model/effort arguments, to be checked against the launcher's exclusive actual command record before accepting results:

```text
-m gpt-5.6-luna -c model_reasoning_effort="high"
```
