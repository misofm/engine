# Luna launcher verification

Launcher: `/tmp/issue539/luna-fresh.py`

Launcher SHA-256: `570ded42a60b51e2cfa0b4dc522c5e4dfa40a893325faaa4a15560c8b648e0d7`

Requested invocation:

```text
python3 /tmp/issue539/luna-fresh.py /tmp/issue554/luna-high-attempt1 /tmp/issue554/luna-high-attempt1.prompt.md high /home/bl/misofm/engine-benchmark-percentile-summary
```

The inspected launcher constructs this model/effort argv:

```text
/home/bl/.local/bin/codex exec -C /home/bl/misofm/engine-benchmark-percentile-summary -s danger-full-access -m gpt-5.6-luna -c model_reasoning_effort="high" -o /tmp/issue554/luna-high-attempt1.md -
```

The launcher writes the actual argv and cwd to `/tmp/issue554/luna-high-attempt1.command.json` with exclusive creation before execution. Launch is authorized only if that generated record exactly names `gpt-5.6-luna` and `model_reasoning_effort="high"`.
