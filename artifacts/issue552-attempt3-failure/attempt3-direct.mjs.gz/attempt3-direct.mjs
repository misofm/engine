import assert from "node:assert/strict";
import { sha256Hex } from "file:///home/bl/misofm/engine-js-hex-recovery/sdk/src/core/asset.ts";
import { hexLower as sdkHexLower } from "file:///home/bl/misofm/engine-js-hex-recovery/sdk/src/core/hex.ts";
import { hexLower as hostHexLower } from "file:///home/bl/misofm/engine-js-hex-recovery/hosts/host-web/web/hex-lower.js";

const literal = new Uint8Array([0x00, 0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef, 0xff]);
for (const hexLower of [sdkHexLower, hostHexLower]) {
  assert.equal(hexLower(new Uint8Array()), "");
  assert.equal(hexLower(literal), "000123456789abcdefff");
}

assert.equal(
  await sha256Hex(new Uint8Array()),
  "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
);
assert.equal(
  await sha256Hex(new TextEncoder().encode("abc")),
  "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
);

await import("file:///home/bl/misofm/engine-js-hex-recovery/hosts/host-web/tests/stem-store-hash-v1.mjs");
