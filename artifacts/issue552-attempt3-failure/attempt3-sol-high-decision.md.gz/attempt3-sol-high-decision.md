# Sol HIGH decision — issue #552 attempt 3 amendment

**Decision: APPROVED FOR ISSUE SYNCHRONIZATION AND FRESH LUNA HIGH IMPLEMENTATION.**

The smallest closable product slice remains #552's two non-Rust lowercase byte-hex authorities.
Attempt 1 established that slice but exposed two finite blockers: strict TypeScript rejects an
unchecked nibble lookup, and the incremental SHA source-provenance record no longer covers the one
helper imported by its formatter adapter. Fixing those defects is necessary to deliver the same
slice; it does not create a second product outcome.

The scope amendment is proportionate and independently testable. It adds only
`hosts/host-web/web/stem-store/incremental-sha256.provenance.json` and
`scripts/check-stem-store-v1.mjs` to the original eight paths. The exact schema pins the primary
source plus exactly one dependency, `../hex-lower.js`; six bounded mutations prove primary bytes,
helper bytes, and missing/extra/renamed/hash-mismatched rosters fail. All original values, adapters,
routes, package boundaries, artifact identities, fixtures, pins, and final qualification duties
remain frozen.

Attempt accounting is conservative: the original Luna work is attempt 1, the historical Sol
correction consumes attempt 2 despite its invalid implementation/Git provenance, and the fresh
actual Luna HIGH recovery is attempt 3. The old branch remains immutable evidence. Root's recovery
branch at `c1c591239f30b080566ebcd2d7708caaa44a5bbd` is the correct implementation base. A failure
after this coherent implementation/review pass is a hard stop and requires a new scope ruling.

The five-command focused gate is sufficient for the first checkpoint because it directly proves
the strict SDK correction, both authorities/adapters, the complete ordinary stem-store suite, the
new provenance mutation contract, and path hygiene. Root must checkpoint that green tranche before
any broader qualification. The unchanged headless/package/browser/workspace gates and final
cross-language census correctly wait for #543 delivery and integration; they are closure gates and
are not removed or waived.

Final artifact-consuming gates use a root-assigned `DELIVERED_ARTIFACT_DIR` containing the exact
six-file artifact delivered by #543/#555 and validated against their then-current pins. The old
`/tmp/issue537-delivery/artifact` is historical evidence only. Root may provision the recovery
worktree with byte-identical already-installed pinned Node dependency directories resolved through
the historical #552 worktree; installs, updates, manifest/lock edits, and committed `node_modules`
remain forbidden. A worker must report any unavailable or identity-mismatched prerequisite.

No source edit, worker launch, build, Git/GitHub mutation, or verifier launch is authorized by this
decision itself. Root must first synchronize this amendment into the numbered issue, then authorize
the fresh Luna HIGH implementation. Actual Sol XHIGH review begins only after the implementation
and full post-#543 evidence are frozen by root.
