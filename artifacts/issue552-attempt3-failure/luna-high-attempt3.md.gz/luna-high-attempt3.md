Attempt 3 stopped at gate 4 failure; gate 5 was not run.

Changed paths:

- `sdk/src/core/hex.ts` — definite bounded nibble lookup for strict indexed access.
- `hosts/host-web/web/stem-store/incremental-sha256.provenance.json` — exact primary/helper closure and hashes.
- `scripts/check-stem-store-v1.mjs` — strict provenance schema validation and six temporary mutation cases.

Gate results:

1. PASS — `/tmp/issue552/attempt3-gate01-evidence.txt`
2. PASS — `/tmp/issue552/attempt3-gate02-evidence.txt`
3. PASS — `/tmp/issue552/attempt3-gate03-evidence.txt`
4. FAIL — `/tmp/issue552/attempt3-gate04-evidence.txt`
5. NOT RUN

Failure: the temporary provenance copy did not preserve the `../hex-lower.js` relative closure, causing `/tmp/hex-lower.js` ENOENT during the helper mutation. No retry or repair was performed.

Other evidence:

- Direct script: `/tmp/issue552/attempt3-direct.mjs`
- Initial snapshot: `/tmp/issue552/attempt3-worker-identity.txt`
- Initial hashes: `/tmp/issue552/attempt3-worker-paths.sha256`
- Dependency snapshot: `/tmp/issue552/attempt3-worker-dependencies.txt`

Final HEAD/status:

`ace10a8f5e7d60260aaa91fa652cd4f46cd06a43`, branch `codex/js-hex-recovery`, upstream `origin/codex/js-hex-recovery`; three uncommitted changed paths listed above.

Dependencies remained unchanged: Node `v22.23.2`, TypeScript `5.9.3`; no install/update, Git/GitHub mutation, output repin, final gate, benchmark, or timed workload occurred.