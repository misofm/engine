# Issue #552 attempt 3 amended implementation brief

## Status and attempt accounting

This amendment is the final implementation attempt allowed by the standing three-attempt rule.

- Attempt 1 is the actual Luna HIGH eight-path implementation checkpoint
  `c1c591239f30b080566ebcd2d7708caaa44a5bbd`.
- Attempt 2 is the later Sol-authored strict-TypeScript correction recorded on the historical
  branch. It was a process-invalid implementation/Git handoff, but it still consumes attempt 2.
  Preserve that branch and its evidence; do not relabel, squash, rewrite, cherry-pick, or claim it
  as Luna work.
- Attempt 3 starts from the clean root-owned recovery worktree at the attempt-1 checkpoint. A fresh
  actual Luna HIGH worker independently diagnoses and fixes the strict TypeScript defect and makes
  the provenance-closure correction authorized below. The worker performs no Git or GitHub
  mutation. Root audits and owns every checkpoint, push, issue-body update, and integration.

If attempt 3 does not pass the frozen gates, stop. Do not weaken a gate or perform a fourth repair
under #552; preserve the evidence and return the issue for a new scope ruling.

## Objective

Complete #552's already-approved two-authority non-Rust byte-to-lowercase-hex slice while:

1. making the internal SDK helper compile under the repository's strict TypeScript configuration;
2. retaining the three thin public/internal adapters and every original value/API/package/browser
   invariant; and
3. updating the stem-store source-provenance evidence so it authenticates the complete executable
   source closure now used by `IncrementalSha256.digestHex()`.

This is a source-provenance closure. It does not authorize changing a product digest, output,
artifact identity, PCM identity, expected corpus value, fixture, or hashing algorithm.

## Frozen implementation base and lineage

Root provisioned `/home/bl/misofm/engine-js-hex-recovery`, branch
`codex/js-hex-recovery`, at clean checkpoint
`c1c591239f30b080566ebcd2d7708caaa44a5bbd`. Use that checkpoint plus only root-integrated delivered
prerequisites that do not alter #552's ten allowed implementation/evidence paths. The stopped
`codex/js-hex-authorities` history is technical and process evidence only; do not transplant its
attempt-2 implementation.

Before editing, record the exact launcher argv/model/effort, cwd, HEAD, status, and SHA-256 identities
of every allowed existing path. The implementation launcher must identify actual `gpt-5.6-luna`
with high reasoning effort.

## Preserved original product contract

The original #552 objective, package-boundary decision, invariants, finite gates, non-goals, and
closure obligations remain in force except for the two-path provenance amendment below.

- `sdk/src/core/hex.ts` remains an internal `hexLower(bytes: Uint8Array): string` authority.
  `sdk/src/core/asset.ts::sha256Hex` retains Web Crypto and delegates only finalized-byte formatting.
  The SDK package export map and `sdk/src/headless/index.ts` remain unchanged.
- `hosts/host-web/web/hex-lower.js` remains the browser-host authority.
  `IncrementalSha256.digestHex()` and qualification's PCM digest adapter delegate only formatting.
  The qualification server exposes only the exact `/web/hex-lower.js` mapping, never the `/web/`
  subtree.
- Each helper returns exactly two lowercase ASCII hexadecimal characters per byte, including
  leading zeroes; empty input returns `""`; non-32-byte inputs work; there is no prefix or separator;
  helpers perform no hashing or I/O.
- Preserve the independent fixed literal
  `Uint8Array([0x00, 0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef, 0xff])`
  => `"000123456789abcdefff"`, the empty-input assertions, the public `sha256Hex` test, all FIPS
  SHA-256 vectors, and streaming/finalization assertions.
- Preserve hashing ownership, digest word order, Web Crypto selection, incremental update/finalize
  behavior, routes, public APIs, fixtures, dependencies, locks, Rust/Cargo source, Wasm ABI, and
  generated/package artifacts.

The strict-TypeScript repair is bounded to `sdk/src/core/hex.ts`. It must prove that each nibble
lookup contributes a definite string under the repository's strict indexed-access rules while
preserving the helper contract. Luna must derive the correction from the attempt-1 source and gate
failure; no exact prior Sol edit is prescribed.

## Exact provenance-closure amendment

The attempt-1 incremental module changed from a self-contained source to a source that imports
exactly one executable helper, `../hex-lower.js`. The existing provenance record authenticates only
the importing file. Amend the record to authenticate both sources.

Keep the existing top-level fields and meanings:

```json
{
  "schema": 1,
  "artifact": "incremental-sha256.js",
  "sha256": "<lowercase SHA-256 of incremental-sha256.js bytes>",
  "dependencies": [
    {
      "artifact": "../hex-lower.js",
      "sha256": "<lowercase SHA-256 of hex-lower.js bytes>"
    }
  ],
  "algorithmAuthority": "NIST FIPS 180-4, SHA-256",
  "implementation": "repository-owned independent JavaScript implementation",
  "reason": "Canonical-PCM stems exceed one-shot digest RAM budgets; SHA-256 remains the schema vocabulary and is verifiable by Sui std::hash::sha2_256. No zero-shipped-code claim is made."
}
```

Keep `schema` at 1: this is the same repository evidence record with its executable dependency
closure made explicit, and no multi-version consumer exists. Do not change `algorithmAuthority`,
`implementation`, or `reason`.

The checker must:

1. continue requiring `artifact` to be exactly `incremental-sha256.js` and verify its recorded hash
   against those file bytes;
2. require `dependencies` to be an array with exactly one entry;
3. require that entry's `artifact` to be exactly `../hex-lower.js`, with no alternate spelling,
   absolute path, or second dependency;
4. require both recorded hashes to be 64 lowercase hexadecimal characters and verify the helper's
   recorded hash against its bytes; and
5. preserve all existing operator-path, static, behavior, budget, and mutation checks.

On the frozen attempt-1 candidate, the observed source identities are:

- `incremental-sha256.js`:
  `e4519729bc0fede4f4ffd815492f7bb22b97c10d0899c05eb1f63e156f5b0e40`;
- `../hex-lower.js`:
  `1eb5564599b0ae99ca404f0c139c0eb9abfe48d488bc55a4bad0b9aacd039560`.

These are review inputs. The worker/checkpoint owner must recompute them from the final candidate;
only those two source-identity fields may change if the corresponding allowed source bytes change.

Extend the checker's existing opt-in `--self-test` mutation proof without introducing a second
harness or new CLI mode. It must demonstrate attributable failure for this finite set:

1. mutate the primary `incremental-sha256.js` bytes;
2. mutate the dependency `hex-lower.js` bytes;
3. remove the dependency roster;
4. add a second dependency entry;
5. rename the required dependency path; and
6. replace the required dependency hash with a different well-formed lowercase SHA-256 value.

Each mutation must fail the same provenance-validation path for its named reason. A mutation may
operate on a temporary copy or on an extracted validator, but must never rewrite the checked-out
source during the gate. The ordinary invocation must still run the full unchanged stem-store
behavior suite.

## Allowed paths

Attempt 3 may change exactly these ten implementation/test/evidence paths:

1. `sdk/src/core/hex.ts`;
2. `sdk/src/core/asset.ts`;
3. `sdk/test/boot-evals.mjs`;
4. `hosts/host-web/web/hex-lower.js`;
5. `hosts/host-web/web/stem-store/incremental-sha256.js`;
6. `hosts/host-web/qualification/qualification.js`;
7. `hosts/host-web/qualification/server.mjs`, limited to the exact helper route;
8. `hosts/host-web/tests/stem-store-hash-v1.mjs`;
9. `hosts/host-web/web/stem-store/incremental-sha256.provenance.json`; and
10. `scripts/check-stem-store-v1.mjs`, limited to the exact source-closure validation and bounded
    mutations above.

The fresh worker should preserve attempt-1 bytes in paths 2 through 8 unless an objective frozen
gate exposes a bounded defect. Any such defect must be reported before expanding the edit.
The numbered issue spec and `/tmp` evidence are root-owned bookkeeping, not worker implementation
paths.

Everything else is read-only. In particular: `sdk/src/headless/index.ts`, package manifests and
locks, generated/`dist` files, qualification artifacts, artifact and PCM pins, fixtures, Rust/Cargo
source, ABI declarations, and the delivered operator path-validation implementation outside the
two added provenance-checker responsibilities.

## Focused attempt-3 gate and checkpoint boundary

Record exact argv, cwd, exit status, pre-command HEAD/status, relevant source hashes, and separate
raw stdout/stderr for every command. Preserve every failure. The recovery worktree does not contain
installed Node dependency directories. Root may provision links to or copies of the byte-identical
already-installed pinned dependency directories resolved through the historical #552 worktree,
after recording their source paths and relevant manifest/lock/package identities. This is
environment provisioning only: do not install or update a package, alter a lock or manifest, or
commit `node_modules`. If a required installed dependency is unavailable or its identity does not
match the checkout's pins, the worker reports that concrete prerequisite and stops the dependent
gate. Run no benchmark or timed workload.

After implementation, actual Luna HIGH runs this smallest focused sequence:

1. `node --experimental-strip-types /tmp/issue552/attempt3-direct.mjs`, where the temporary script
   is the existing `/tmp/issue552/gate01-direct.mjs` adapted only to the recovery-worktree absolute
   paths. It imports both helpers and SDK `sha256Hex`, asserts the frozen empty/direct literal and
   existing `sha256Hex` vectors, then imports `stem-store-hash-v1.mjs` so the preserved incremental
   SHA vectors and `digestHex()` adapter assertions run. Expected text stays literal and may not be
   derived with another formatter.
2. `bash scripts/check-sdk-types.sh`.
3. `node scripts/check-stem-store-v1.mjs`.
4. `node scripts/check-stem-store-v1.mjs --self-test`.
5. `git diff --check` against the worktree plus exact changed-path censuses for (a) the uncommitted
   attempt-3 tranche against `c1c591239f30b080566ebcd2d7708caaa44a5bbd` and (b) the cumulative
   #552 candidate against attempt 1's parent `e684275cb349e49a66e73f7f030da6520dd63607`.
   The former is a subset of the ten paths and the latter contains only the ten paths. No generated,
   output, artifact, fixture, lock, Rust, Cargo, ABI, or PCM pin may change.

When all five are green, stop with one coherent uncommitted tranche. Report exact evidence paths
to root. Root audits status/diff/source identities, commits and pushes the exact-path checkpoint,
and synchronizes the amended issue record before any later gate or review. Do not layer further
work while that checkpoint is pending.

## Deferred final qualification after #543 delivery

The focused checkpoint does not close #552. The final qualification and semantic census wait until
#543 is delivered through its own workflow and root integrates that delivered prerequisite without
assigning its Rust changes to #552. On that integrated candidate, run all original obligations once:

1. rerun the direct helper/adaptor/vector command;
2. `node scripts/check-stem-store-v1.mjs`;
3. `node scripts/check-stem-store-v1.mjs --self-test`;
4. `bash scripts/check-sdk-types.sh`;
5. `bash scripts/check-sdk-headless.sh "$DELIVERED_ARTIFACT_DIR"`;
6. `bash scripts/sdk-package.sh check "$DELIVERED_ARTIFACT_DIR"`;
7. from `hosts/host-web/qualification`, `npm run session-identities`;
8. from `hosts/host-web/qualification`,
   `npm run qualify -- --artifacts "$DELIVERED_ARTIFACT_DIR" --browser chromium --check-matrix --self-test-mutations`;
9. `bash scripts/check-workspace-policy.sh`;
10. full committed original-base and current-base `git diff --check`, exact allowed-path and package
    artifact census, and clean status; and
11. the original cross-language semantic census over `crates`, `hosts`, `sdk`, `tools`, and
    `sidecars` (`*.rs`, `*.ts`, `*.js`, `*.mjs`; excluding `node_modules`, `dist`, `target`) for
    `toString(16)` with `padStart(2)`, lowercase nibble tables, Rust `:02x`, and
    `char::from_digit`, inspecting every hit.

The final census passes only when the three #552 residual call sites delegate; the only raw
unprefixed whole-byte lowercase encoders are `engine::hex_lower`, SDK `hexLower`, and host-web
`hexLower`; and every other hit is a concrete parser, decorated diagnostic/repin, fixed-width
integer, uppercase, or word-format exclusion already classified by #543.

Before these gates, root assigns `DELIVERED_ARTIFACT_DIR` to the exact six-file qualification
artifact directory delivered by #543/#555 and records that directory and its producer checkpoint.
Recheck its filenames, sizes, and SHA-256 identities against the then-current pins delivered by
#543/#555. Never regenerate or repin it under #552. `/tmp/issue537-delivery/artifact` is retained
only as historical evidence for #552's earlier stopped gate run and is not the final qualification
input. Required remote qualification must still supply the existing Chromium, Firefox, and WebKit
matrix before merge.

After the final finite gates, root freezes an evidence checkpoint. Only then may an actual Sol
XHIGH verifier receive the candidate, amended issue, complete raw evidence, lineage record, and
#543 census classification. Sol XHIGH PASS, required CI PASS, merge, matching GitHub issue closure,
and remote-state verification are all required before #552 or audit #349 CP-20 can be called
delivered.

## Non-goals

- No generic formatting, provenance, mutation, benchmark, or test framework.
- No new crate/npm dependency, package export, public helper, broad server route, C/Wasm ABI, or
  cross-memory conversion path.
- No parser, decorated diagnostic/repin, fixed-width integer, uppercase, or word-format rewrite.
- No hash replacement, hash ownership move, output/artifact/PCM/corpus repin, fixture expansion,
  generated artifact update, benchmark, DSP/audio change, or timed workload.
- No Rust implementation or #543 delivery work inside #552.
