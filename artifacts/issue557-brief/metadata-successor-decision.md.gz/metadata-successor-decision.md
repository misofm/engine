# Sol HIGH decision: TOOL9 session/conformance metadata acquisition

## Verdict

**APPROVE FOR NUMBERING.** “Share session and conformance host/toolchain fact acquisition” is the smallest current metadata duplication slice that can close independently without normalizing unrelated schemas. Use clean synchronized `main` `30f658ee1c0c7d86002f5f2fea075a5dfa8a7c2c` as the numbering baseline. No implementation starts until root creates and synchronizes the matching numbered local/GitHub issue.

## Basis

Current source confirms that session and conformance independently perform the same bounded system/toolchain/environment acquisition: CPU file, physical and logical cores, kernel, governor fallback, `rustc -V/-Vv`, two verbose fields, and seven common non-governor runner variables. `bench-support::sysinfo` already owns their formerly duplicated physical-core probe, so extending that authority has no new dependency edge, crate, runtime surface, or record framework.

Their records are not duplicates. Session accepts a flexible trimmed CPU key/value, names the compiler field `rustc_version`, and adds `runtime_or_browser`. Conformance requires the exact tabbed CPU prefix, names the same value `compiler`, and adds git identity/dirty state. Both own different field arrays and missing names. Timestamps, git/runtime fields, missing lists, and JSON projections therefore remain local. Synthetic shared-fact tests must prove these differences rather than erase them.

Unavailable behavior is part of the contract: failed/unsuccessful/non-UTF-8/empty commands use `"unknown"`; raw CPU unavailability remains distinguishable until local parsing; successful empty governor-file content remains empty; only governor read failure consults the memoized environment; empty/missing/non-Unicode variables use `"unknown"`; and only the literal sentinel enters each local missing list. A private injected-source seam in `sysinfo.rs` is justified to test this finite matrix without mutating PATH or process environment. It must not become a generic command/filesystem framework.

## Scope control

Only `tools/bench-support/src/sysinfo.rs`, the two subject files, and the existing bench policy/checker mutation pair are implementation paths. There is no manifest, lockfile, validator, fixture, artifact, schema, other benchmark subject, or product edit. No benchmark or timed workload runs.

The structural checker is limited to requiring both delegations and forbidding the known common acquisition spellings in these two subjects. One reintroduced-probe mutation and one removed-delegation mutation are sufficient. Do not build another policy abstraction or mutation campaign.

Delivered #554 resolves the proven six-field `u64` percentile duplication only. This successor must leave TOOL9 partial and explicitly retain the rack/builtins, graph/protocol, effect-interchange, effect-contract, inline numeric-summary, and schema-writer rows for later delivery or reviewed keep-local decisions.

## Routing

Actual Luna HIGH implements attempt 1; Sol HIGH coordinates; actual Sol XHIGH verifies. Root owns all Git/GitHub state, checkpoints, pushes, issue synchronization, PR/CI delivery, and worktree cleanup. Review fails on any projection/fallback/timestamp/record drift, hidden timed execution, broadened policy framework, or claim that another TOOL9 residual is complete.
