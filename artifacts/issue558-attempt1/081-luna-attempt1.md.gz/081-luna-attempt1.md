Issue #558 attempt 1 passed.

Changed only [scripts/check-stem-store-v1.mjs](/home/bl/misofm/engine-provenance-fixture/scripts/check-stem-store-v1.mjs), staging `stem-store/` with its exact parent-level `hex-lower.js` and cleaning the temporary root in `finally`.

- Self-test: PASS, status 0
- Changed-path/diff gate: PASS, status 0
- Evidence: `/tmp/issue558/`
- Change remains uncommitted for root’s exact-path checkpoint.