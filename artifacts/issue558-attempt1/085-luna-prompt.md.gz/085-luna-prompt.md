You are the sole actual Luna HIGH implementation worker for issue #558 attempt 1 in
/home/bl/misofm/engine-provenance-fixture at frozen starting HEAD
ec70745f21ed4117523ac2102b2973a11a75b803.

Read AGENTS.md, .github/ISSUE_SPECS/558-repair-stem-store-provenance-self-test-fixture.md,
and /tmp/issue349-partials/552-sol-xhigh-attempt3.md completely before acting.

This is a separate one-path qualification-fixture issue after #552 exhausted three
attempts. Do not perform or suggest any fourth #552 product repair. Your only permitted
repository edit is scripts/check-stem-store-v1.mjs, and only its existing provenance
self-test temporary fixture topology, cleanup, and assertions. Production validator
behavior, all product files, provenance records/hashes/pins, fixtures, expected values,
routes, schemas, dependencies, lockfiles, Rust/Cargo, issue specs, and Git/GitHub state
are frozen. Do not run npm, browser tests, benchmarks, or introduce a framework.

Before editing, preserve under /tmp/issue558/luna-attempt1-preflight-* separate raw
stdout, raw stderr, numeric status, exact argv, cwd, and source identity for:
git rev-parse HEAD; git status --short; and sha256sum of
scripts/check-stem-store-v1.mjs,
hosts/host-web/web/stem-store/incremental-sha256.js,
hosts/host-web/web/hex-lower.js, and
hosts/host-web/web/stem-store/incremental-sha256.provenance.json.
Do not combine streams and do not line-prefix or substitute output.

Implement the minimum correction so the existing temporary fixture stages the exact
source closure selected by the literal ../hex-lower.js dependency: stem-store contains
the provenance record and primary incremental-sha256.js, while hex-lower.js is at its
exact parent path. Ensure cleanup occurs on PASS and failure. Preserve the existing
--self-test CLI and ordinary/budget/operator-path/mutation ledger. All six already
frozen provenance negative cases must reach validateSourceProvenance() and be rejected
for their named semantic reason, never a filesystem setup error: primary bytes, helper
bytes, roster removed, extra entry, renamed dependency, and different well-formed
dependency hash. Never mutate the checkout in those tests.

After editing, run exactly once and in this order, stopping at the first failure:

1. node scripts/check-stem-store-v1.mjs --self-test
2. A single changed-path/diff gate invocation that runs git diff --check and rejects
   every changed path other than scripts/check-stem-store-v1.mjs relative to
   ec70745f21ed4117523ac2102b2973a11a75b803.

For each gate preserve separate raw stdout, stderr, numeric status, exact argv, cwd,
and source identity under /tmp/issue558. Do not use combined line-prefixed records or
output substitution. The changed-path/diff gate must be executed once total, not as
separate repeated checks. Do not rerun a failed gate. Do not run extra tests.

If either gate fails, stop immediately and report the failure without further edits or
commands. If both gates pass, stop immediately with the green source change
uncommitted for root's exact-path checkpoint. Do not commit, push, edit an issue, call
GitHub, or delegate. Report changed file, concise rationale, evidence paths, and gate
statuses to the coordinating Sol.
