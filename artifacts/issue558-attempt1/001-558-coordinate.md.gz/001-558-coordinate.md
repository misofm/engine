Issue #558 attempt 1 is green and paused uncommitted for root checkpoint.

- Actual worker: `gpt-5.6-luna`, reasoning `high`; argv verified in `/tmp/issue558/luna-attempt1.command.json`.
- Sole changed path: `scripts/check-stem-store-v1.mjs`.
- Full `--self-test`: status `0`; all six provenance `RED:` cases and prior mutation ledger passed.
- One-time diff/changed-path gate: status `0`.
- Separate raw stdout, stderr, status, argv, cwd, and source identity are preserved under `/tmp/issue558/`.
- Sol made no source, spec, Git, GitHub, pin, hash, or product edits.
- No XHIGH verifier was started; root must checkpoint/freeze first.