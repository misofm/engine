#!/usr/bin/env bash
set -u
name=$1
shift
repo=/home/bl/misofm/engine-470-deferred-scalar-pairing
out=/tmp/issue470-postpin-evidence
cd "$repo" || exit 125
utc=$(date -u +%Y-%m-%dT%H:%M:%SZ)
cwd=$(pwd -P)
head=$(git rev-parse HEAD)
git_status=$(git status --short --branch)
printf -v argv '%q ' "$@"
printf 'pre_command_utc=%s\npre_command_cwd=%s\npre_command_head=%s\npre_command_status=%s\nargv=%s\n' "$utc" "$cwd" "$head" "$git_status" "$argv" > "$out/$name.meta"
sha256sum hosts/host-web/web/miso-engine-v1-audio-worklet-artifact.sha256 hosts/host-web/tests/browser-v1/expected.json >> "$out/$name.meta"
sha256sum /tmp/issue470-qualified-artifact/miso-engine-v1-audio-worklet.simd128.wasm >> "$out/$name.meta"
set +e
"$@" > "$out/$name.stdout" 2> "$out/$name.stderr"
rc=$?
set -e
printf 'exit=%s\n' "$rc" >> "$out/$name.meta"
printf '[%s] exit=%s\n' "$name" "$rc"
cat "$out/$name.stdout"
cat "$out/$name.stderr" >&2
exit "$rc"
