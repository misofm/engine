Implemented attempt 2’s bounded correction in [scripts/check-conformance-boundaries.sh](/home/bl/misofm/engine-protocol-conformance-boundary/scripts/check-conformance-boundaries.sh).

- Pre-edit HEAD: `114ee981bbdcf88a64ec602eb828eb32e4b00815`; worktree clean.
- Final status: only ` M scripts/check-conformance-boundaries.sh`.
- Final script SHA-256: `812cbdbf3b3fa1cd30214f5c42c178152a54db212a81e8d9850c452855ca8766`.
- Exact child-path exemptions and literal parent guard verification implemented.

All authorized gates passed:

- Shell syntax/positive checker: `0`.
- Controller guard red control: checker `1`; restoration/live checker `0`.
- Session-wire guard red control: checker `1`; restoration/live checker `0`.
- Forbidden export red control: checker `1`; restoration/live checker `0`.
- Protocol cargo check/tree/no-conformance assertion: `0/0/0`.
- Full-base and working-tree diff checks: `0/0`.

Evidence is under `/tmp/issue542/attempt2/`, including `gate-1...` through `gate-4...` logs and `preserved-wasm-artifacts.tsv`. Both retained Wasm artifacts matched accepted size/hash identities and were not rebuilt.

No Git/GitHub mutations or commits performed. Root should checkpoint this one-file tranche before further work.