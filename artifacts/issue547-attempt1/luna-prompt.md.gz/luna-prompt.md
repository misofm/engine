You are Luna HIGH implementing attempt 1 for active issue #547 in the provided worktree. Read AGENTS.md and `.github/ISSUE_SPECS/547-native-runner-process-boundary.md` completely before acting.

Sol HIGH has frozen the smallest scope as follows:

- Add exactly the executable-boundary integration coverage requested under `tools/native-pcm-runner/tests/`.
- Exercise Cargo's actual binary path, preferably `env!("CARGO_BIN_EXE_native-pcm-runner")`, by spawning the real executable with `std::process::Command`.
- In one coherent integration test, run accepted frozen fixture `fixtures/native-pcm-runner/v1/riff-48000.json` with source root `fixtures/native-pcm-runner/v1`, `--frames 1024`, and a unique temporary output. Require success exit, exactly empty stdout and stderr, exact output length 8192 bytes, and absence of the exact sibling `OUTPUT.issue073.partial` after completion.
- In the same executable-boundary test, exercise the existing closed-CLI rejection `--frames 0` with an otherwise complete four-option command. Require exit code 2, exactly empty stdout, exact stderr bytes `native-pcm-runner.v1\tcli\tframes.zero\n`, and no final or partial output.
- Use robust per-process unique temp-directory support in the integration test and clean it up. Use only the standard library unless an existing support dependency is truly necessary.

Hard scope boundaries:

- You may change only the new integration test and, only if indispensable, existing test support/development dependencies. Do not modify production code, audio code, parser behavior, CLI/error contracts, fixture bytes, manifests, documentation, scripts, lockfiles, pins, or issue specs.
- Do not add or verify any output digest. Exact length is the fixture truth required here.
- No benchmark, browser, repin, Git/GitHub mutation, commit, push, branch operation, PR operation, issue operation, full qualification run, or separate verifier launch. Root owns Git/GitHub, required qualification, and Sol xhigh verification.
- If any expectation contradicts executable behavior or requires a production edit, stop immediately. Preserve the failing command and raw output in `/tmp/issue547`, report the contradiction, and leave production untouched.
- Keep all Cargo output under `CARGO_TARGET_DIR=/tmp/issue547-target`.
- Produce one coherent focused-green tranche, then pause for root's exact-path commit/push. Do not begin any further tranche.

Evidence requirements:

1. Before editing, independently capture exact `git rev-parse HEAD`, `git status --short`, and SHA-256 hashes for all source/fixture/manifest files you rely on. Preserve them under `/tmp/issue547/luna-pre-*`; do not overwrite `/tmp/issue547/precommand-*`.
2. Preserve every command as a `.command.json` containing argv/cwd/relevant environment, exact stdout, exact stderr, and numeric exit status in separate files under `/tmp/issue547`. Never overwrite a prior capture; preserve failures. Raw captures must remain outside the repository.
3. Run the focused integration test so both spawned-process cases actually execute. Run the complete existing `native-pcm-runner` tests, affected strict Clippy (`--all-targets --all-features -- -D warnings`), `cargo fmt --all -- --check`, `git diff --check`, and `bash scripts/check-workspace-policy.sh .`. Do not run benchmarks or full qualification.
4. In addition to the test assertions, create a direct executable witness from the Cargo-built binary for both accepted and rejected commands. Preserve raw stdout/stderr/status. Preserve output metadata including exact byte length and final/partial existence for each case. Use a fresh evidence-owned directory beneath `/tmp/issue547`, not the repository, and do not retain generated PCM inside the worktree.
5. At the end report: changed paths; concise implementation description; every gate command and status; exact raw-evidence locations; final `git status --short`; post-edit hashes for changed paths; and explicit confirmation that production/audio/parser/pin/fixture files are unchanged. Do not write your own final output file—the delegation helper owns that destination.

Current coordinator baseline: HEAD `77aa69fef3b6f36fd1e8f3a75571958e64a36610`, clean status. The issue activation commit is atop synchronized main `86d5b4bd`. Coordinator baseline evidence is already in `/tmp/issue547/precommand-head.txt`, `/tmp/issue547/precommand-status.txt`, and `/tmp/issue547/precommand-source-hashes.sha256`.
