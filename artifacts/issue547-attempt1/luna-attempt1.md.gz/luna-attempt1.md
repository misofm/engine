Implemented attempt 1 in:

[process_boundary.rs](/home/bl/misofm/engine-native-runner-process-boundary/tools/native-pcm-runner/tests/process_boundary.rs)

The single integration test spawns the real Cargo binary for accepted and `--frames 0` rejection cases, verifies diagnostics, output length, and partial-file absence. Temp directories are process-unique and cleaned up.

Gates:

- Focused integration test: PASS (`focused-test-2`)
- Complete runner tests: PASS — 19 library + 1 integration test
- Strict Clippy: PASS
- rustfmt check: PASS
- `git diff --check`: PASS
- Workspace policy: PASS
- Direct executable witness: PASS — accepted 8192 bytes/status 0; rejected status 2, exact stderr, no outputs
- Pre/post relied-on hashes: unchanged

Evidence is preserved under `/tmp/issue547/`, including command JSON, stdout, stderr, and status files. Direct witness metadata is in:

- `/tmp/issue547/direct-accepted-*`
- `/tmp/issue547/direct-rejected-*`
- `/tmp/issue547/direct-witness-1/`

Final status:

```text
?? tools/native-pcm-runner/tests/process_boundary.rs
```

Post-edit SHA-256:

```text
22a227d33a8d66ed6f03a9e4eb556e61ac2525edc9a693e24eea5d8467287683
```

Production, audio, parser, CLI contract, pin, fixture, manifest, and lockfile files are unchanged. No commit, push, or GitHub operation was performed; paused for root’s exact-path checkpoint.