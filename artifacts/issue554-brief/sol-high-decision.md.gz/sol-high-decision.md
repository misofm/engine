# Sol high scope decision: audit #349 TOOL9

Decision: **APPROVE the six-field percentile-summary slice for numbering and Luna high attempt 1. Keep TOOL9 partial.**

The source census on clean `main` `a3b4ed763c47658e10fc111e2cfcbd141c77f064` found one narrow, byte-preservable duplicate ready to implement: rack and builtins own the same six `u64` summary fields and selection positions, while shared `bench_support::stats::Percentiles` already owns five of them. Adding p99.9 to that shared record and deleting the two local records is smaller than a half-day, has no runtime/DSP scope, and can be proved with synthetic unit records plus the existing static policy.

The brief deliberately does not merge the seven local `Metadata` structs or the rack/builtins JSON writers. The metadata records encode materially different required/optional rules, scalar types, placeholder handling, field names, missing lists, and probe sources. Rack and builtins record writers also publish different schemas, units, identity sets, audit fields, and null behavior. Treating their names as proof of duplicate behavior would create the generic benchmark framework the task forbids and risk silent schema movement.

The remaining metadata work is real rather than dismissed. Session and conformance share the largest concrete acquisition tail and are the next bounded candidate. Rack and builtins share a raw 16-environment-name inventory but require distinct projections. Graph and protocol have different fallbacks, and effect-interchange has a different required/optional runner boundary. The attached residual map freezes each distinction and the continuation order.

Review must fail the percentile attempt if it changes any record key/order/value, observation cardinality, metadata fallback, hash input/ownership, workload, or timed scope; if a second percentile-summary owner remains; or if the structural gate cannot detect a reintroduced owner. No benchmark run, descriptive timing, artifact promotion, package/dependency change, or source outside the five allowed paths belongs to this slice.
