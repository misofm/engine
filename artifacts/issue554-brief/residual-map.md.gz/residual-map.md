# Audit #349 TOOL9 current residual map

Baseline inspected: clean synchronized `main` at `a3b4ed763c47658e10fc111e2cfcbd141c77f064` on 2026-09-07. This is a source census, not a benchmark run. Original counts are not reused.

## Statistical ownership

| Surface | Actual current behavior | Classification / next decision |
| --- | --- | --- |
| `tools/bench-support/src/stats.rs` | Sole nearest-rank function; five-field `u64` summary used by console and wasm-console | Delivered foundation from PR #386. Immediate slice adds the already published p99.9 value. |
| `tools/bench/src/rack.rs:890-913` | Local six-field `u64` summary; exact 1,000-observation assertion; shared per-mille selector | True duplicate of builtins plus the shared five fields. Included in the numbered-ready slice. |
| `tools/bench/src/builtins.rs:1752-1775` | Local six-field `u64` summary over any nonempty sample; shared nearest-rank selector | True duplicate of rack apart from the caller precondition. Included in the numbered-ready slice; caller-specific precondition stays local. |
| `session`, `graph`, `effect-contract`, `effect-interchange`, `conformance` | Each sorts subject-owned observations and projects min/p50/p95/p99/p99.9/max directly through the shared nearest-rank law; some use `u128`, calculate extra series/totals, or convert to per-sample floats | Boilerplate remains, but there is no second percentile-selection algorithm. A generic numeric summary would cross five distinct record/measurement shapes. Do not pull it into the immediate `u64` type deletion. Re-audit after that slice; if retained, brief it separately with exact synthetic record comparisons rather than calling it complete by type count. |
| Rack/builtins record writers | Rack emits issue-038 `ns_per_frame` plus render-audit and identity fields; builtins emits issue-035 typed/null preparation and render records in a fixed key vector | Legitimate schema owners. Their formatters are not interchangeable. Consolidating them would be a generic benchmark-record framework and would couple independent published schemas. Keep local unless a concrete byte-equivalent schema family is proved later. |

## Metadata ownership

The seven local `Metadata` names do not establish seven duplicate implementations. Their sources, validation, types, and fallback values differ.

| Subject | Collection and projection law | True overlap / disposition |
| --- | --- | --- |
| `session` (`session.rs:285-414`) | Probes CPU model, physical/logical cores, kernel, governor, `rustc -V/-Vv`; reads eight runner fields; uses string `"unknown"`; emits timestamp and a sorted-by-construction missing list | Shares a large host/toolchain acquisition tail with conformance. This is the clearest remaining metadata duplicate and should be the next separately briefed TOOL9 slice. Keep the session record struct and field names local. |
| `conformance` (`conformance.rs:178-318`) | Same common probes and fallbacks, plus git commit and dirty state; no runtime/browser field | Same shared-host-facts candidate as session. Git identity and its local record projection remain conformance-owned. A bounded successor should introduce injectable parsing/source tests and preserve both schemas byte-for-byte for synthetic facts. |
| `graph` (`graph.rs:89-103,473-542`) | Probes rustc/CPU/kernel itself; treats `unknown`, `not measured`, `default`, and `target-default` as incomplete while sometimes retaining the placeholder value; combines OS and kernel | Overlaps only at low-level sources. Its placeholder-retention law differs from session/conformance. Do not merge it until a successor freezes those distinctions. |
| `rack` (`rack.rs:775-836`) | Projects the canonical 16 runner variables as optional strings; rejects empty, `unknown`, `default`, and every non-ASCII value; record keys include `architecture`, `logical_cores`, `physical_cores` | Shares the same 16 environment names with builtins but not its types or acceptance law. A later small slice may centralize the raw 16-name inventory/single snapshot access while leaving filtering and record keys local. |
| `builtins` (`builtins.rs:1219-1411`) | Projects the same 16 variables; core counts parse as positive `u32`; text allows Unicode but rejects controls, empty, `unknown`, and `default`; missing names are sorted/deduplicated; identities require exact lowercase hex | Same raw-name inventory as rack; schema and validation are intentionally distinct. Local typed record is legitimate. Centralize only raw names/access after tests pin Unicode, numeric zero/parse failure, ordering, nulls, and identity panic behavior. |
| `effect-interchange` (`effect_interchange.rs:885-963`) | Ten required nonempty identity/toolchain variables and eight optional legacy runner variables (`CPU_MODEL`, etc.); optional absence becomes empty string and a sorted lowercase missing name | Different required/optional boundary and different environment vocabulary. Local record is legitimate. Any migration to canonical runner names changes the external runner contract and needs its own issue. |
| `protocol` (`protocol.rs:1436-1551`) | Direct CPU/governor/rustc probes; runner target/host values default to `"unknown"`; wasm byte counts parse with `0` fallback; no missing-metadata array | Its fallback and schema laws differ. It can consume future raw host facts, but its zero-vs-unknown and no-missing-list behavior must remain local. |

Additional live surfaces omitted by the seven-type handoff must remain visible:

- `tools/bench/src/effect_contract.rs:335-342` reads individual shared-snapshot variables but rewrites `"` to `'` before interpolating into quoted JSON. That is a correctness/encoding candidate, not a value-preserving metadata consolidation: routing it through the shared RFC 8259 escaper would change decoded values containing quotes. It needs an explicit bounded ruling and adversarial string fixtures; do not smuggle it into the percentile slice.
- `tools/bench/src/rack.rs` also reads round and required SHA identities outside its metadata record. Those are contract admission checks, not duplicate machine-fact collection.
- `tools/audit/src/record.rs`, `tools/bench/src/console.rs`, and `tools/wasm-console/src/main.rs` already consume the shared metadata record/snapshot and are delivered evidence, not residual work.

## Ordered continuation

1. Deliver the numbered-ready six-field `u64` percentile-summary slice.
2. Rebrief session/conformance shared host/toolchain acquisition as the next bounded metadata slice. Preserve local record structs, timestamp timing, conformance git fields, session runtime/browser field, command failure/empty/non-UTF-8 fallbacks, CPU parsing, governor environment fallback, and missing-list names.
3. Separately assess the rack/builtins raw 16-field inventory. Share raw names and one snapshot lookup only if pure tests prove both existing validation projections exactly; do not unify their record structs.
4. Decide the effect-contract quoted/control-character case as a correctness issue because strict shared escaping changes the currently emitted decoded value for quotes.
5. Re-audit graph/protocol and the inline `u128` summaries after those slices. Close TOOL9 only when each remaining row is delivered or has a reviewed keep-local decision grounded in distinct behavior, not merely a different type name.
