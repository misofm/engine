## Sol XHIGH verdict: FAIL

Issue #552 counted attempt 3 is exhausted at frozen commit `c3cdb929cb7686c1cf3cfcf6305eac5feab70f37`, directly based on `ace10a8f5e7d60260aaa91fa652cd4f46cd06a43`.

Confirmed failure:

- Gates 1–3 passed: direct vectors, strict SDK types, and ordinary stem-store behavior.
- Gate 4 exited `1`.
- Only the primary-source mutation completed attributably.
- The helper mutation resolved `join(temporary, "../hex-lower.js")` to `/tmp/hex-lower.js` and failed with `ENOENT` before provenance validation. See [check-stem-store-v1.mjs](/home/bl/misofm/engine-js-hex-recovery/scripts/check-stem-store-v1.mjs:484).
- The remaining four provenance mutations did not execute.
- Gate 5 was not run and receives no credit from the later read-only coordinator diff inspection.

Bounded review found no additional concrete source defect in the three-path attempt-3 delta. The SDK lookup is strictly typed, the production provenance validator correctly authenticates both exact source files, and the recorded hashes match their bytes. There is one additional evidence-format deviation: gate output/status was preserved in combined line-prefixed records instead of separate raw stdout/stderr/status files. It does not obscure this FAIL, but successor evidence must comply exactly.

Provenance is valid:

- The preserved launcher record and transcript header identify actual `gpt-5.6-luna`, reasoning effort `high`.
- The artifact manifest covers 19 files with zero compressed or uncompressed hash/size mismatches.
- Invalid attempt 2 remains at `a5b7c298539fcd3da8f5e497579d5d08b5f5337a` on the local and remote-tracking `codex/js-hex-authorities` refs.
- Attempt 2 is not an ancestor of the frozen attempt-3 checkpoint and was not transplanted.

Required rescope obligations are finite:

1. Root preserves and synchronizes this failed checkpoint; no fourth #552 repair.
2. Create and synchronize a new stateless qualification-tooling issue, using `c3cdb929` as an explicit prerequisite.
3. Limit implementation to the temporary provenance-fixture topology in `scripts/check-stem-store-v1.mjs`; all #552 product, validator, provenance, hash, pin, and artifact bytes remain read-only.
4. Prove all six mutations reach `validateSourceProvenance()` and fail for their named semantic reason—never a filesystem/setup error.
5. Run the complete `--self-test` ledger and exact changed-path/diff gate once, preserving separate raw stdout, stderr, and status evidence.
6. Retain all deferred #543/#555 artifact, full qualification, cross-language census, browser-matrix, CI, merge, GitHub synchronization, and CP-20 closure obligations.

The existing [rescope decision](/tmp/issue552/rescope-decision.md:1) has the correct bounded shape but must be numbered and synchronized by root before implementation. No files or repository state were changed during this review.