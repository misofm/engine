# Issue #552 attempt 3 — Sol HIGH failure coordination record

## Verdict

**ATTEMPT 3 FAILED AT FOCUSED GATE 4. STOPPED UNDER THE THREE-ATTEMPT RULE.**

No implementation retry, source correction, gate rerun, final qualification, or verifier launch is
authorized in #552. Root may preserve the exact candidate in a candid failed checkpoint and obtain
the requested actual Sol XHIGH failure adjudication before activating any new scope.

## Candidate and actual worker provenance

- Worktree: `/home/bl/misofm/engine-js-hex-recovery`
- Branch: `codex/js-hex-recovery`
- Frozen HEAD throughout worker execution:
  `ace10a8f5e7d60260aaa91fa652cd4f46cd06a43`
- Upstream before and after worker execution:
  `origin/codex/js-hex-recovery` at the same commit
- Worker launcher record: `/tmp/issue552/luna-high-attempt3.command.json`
- Worker model: actual `gpt-5.6-luna`
- Reasoning effort: `high`
- Worker cwd: `/home/bl/misofm/engine-js-hex-recovery`
- Launcher status: `0` (the worker completed its assigned stop/report behavior; this is not a gate
  PASS)

Verified launcher argv:

```text
/home/bl/.local/bin/codex
exec
-C
/home/bl/misofm/engine-js-hex-recovery
-s
danger-full-access
-m
gpt-5.6-luna
-c
model_reasoning_effort="high"
-o
/tmp/issue552/luna-high-attempt3.md
-
```

The worker made no Git or GitHub mutation. It did not install or update dependencies, edit a
manifest/lock, run a final artifact/browser/workspace/census gate, or run a benchmark/timed
workload.

## Dependency identity

Recorded before focused gates in `/tmp/issue552/attempt3-worker-dependencies.txt`:

- Node: `v22.23.2`
- TypeScript: `5.9.3`
- resolved compiler:
  `/home/bl/misofm/engine-js-hex-recovery/sdk/node_modules/typescript/bin/tsc`
- `sdk/package.json`:
  `62641970eb223ab6c81b97a077e44c3b9d1aa2179513df2f00d235a5546509c0`
- `sdk/package-lock.json`:
  `dee524dd698d40dbcc99fced7e55e651fd5d96b0957a2ddb1cd59c7c486c03d4`
- provisioned `sdk/node_modules/.package-lock.json`:
  `f3c361b62f081643a016cca38e1bf08ec29f0f858355c515f786972245d10968`

## Exact uncommitted candidate

The worker changed exactly three authorized paths:

1. `sdk/src/core/hex.ts`
2. `hosts/host-web/web/stem-store/incremental-sha256.provenance.json`
3. `scripts/check-stem-store-v1.mjs`

The other seven attempt-1 implementation/test paths remained byte-identical. The final changed-file
identities recorded before all four gates were:

- `sdk/src/core/hex.ts`:
  `527c820b255dcdf9b4ce15ab0b9b59c3bea3f451b7f9941cc2ea4dd37bca4d1b`
- `incremental-sha256.provenance.json`:
  `fd6200bb0dd8b5663bd22354c957d15f7cca32a15555c2974caf86e87ded595d`
- `scripts/check-stem-store-v1.mjs`:
  `6f9b4ebc9a95e924474d72ccf012670ce4cd6d533f2531be65b1f7aaf02b04e5`

The TypeScript helper uses a bounds-proven nibble accessor. The provenance record retains schema 1
and the frozen authority/implementation/reason, pins the primary source, and names exactly one
dependency `../hex-lower.js` with its independently computed source hash. The checker validates
the exact record shape, fixed primary/dependency names, lowercase 64-character hashes, both file
identities, and the frozen descriptive fields. It also defines the six required mutation cases.

## Focused gate record

The worker ran the gates once in order and stopped at the first nonzero result:

1. **PASS (0)** — direct SDK/browser helper literals, SDK `sha256Hex`, and preserved incremental
   vectors/adaptor tests.
   - argv: `/tmp/issue552/attempt3-gate01-argv.txt`
   - evidence: `/tmp/issue552/attempt3-gate01-evidence.txt`
2. **PASS (0)** — `bash scripts/check-sdk-types.sh`.
   - argv: `/tmp/issue552/attempt3-gate02-argv.txt`
   - evidence: `/tmp/issue552/attempt3-gate02-evidence.txt`
3. **PASS (0)** — ordinary `node scripts/check-stem-store-v1.mjs`, including operator-path and
   complete unchanged behavior suite with budget assertions skipped by contract.
   - argv: `/tmp/issue552/attempt3-gate03-argv.txt`
   - evidence: `/tmp/issue552/attempt3-gate03-evidence.txt`
4. **FAIL (1)** — `node scripts/check-stem-store-v1.mjs --self-test`.
   - argv: `/tmp/issue552/attempt3-gate04-argv.txt`
   - evidence: `/tmp/issue552/attempt3-gate04-evidence.txt`
5. **NOT RUN by the worker** — the frozen gate-5 wrapper was not created or invoked.

Gate 4 ran the ordinary suite successfully and printed `RED: provenance primary bytes mutated`,
showing that the first new negative case reached and passed its intended rejection. The second case
then failed before validation with:

```text
Error: ENOENT: no such file or directory, open '/tmp/hex-lower.js'
```

`runProvenanceSelfTest()` copies the `web/stem-store` runtime directory directly to a newly created
temporary directory and passes that directory as `provenanceRoot`. The recorded dependency is
`../hex-lower.js`, so resolution correctly points to the temporary directory's parent. The fixture
did not stage the helper at that parent path. This is a substantive defect in the new mutation
harness fixture, not a product hash/value failure and not a defect in ordinary provenance
validation. Only one of the six new negative cases completed; the required bounded mutation proof
is incomplete.

The worker stored each gate's stdout, stderr, status, pre-command HEAD/status, and source identities
inside its corresponding `attempt3-gateNN-evidence.txt`; it did not create separate raw stream and
status files as requested. The line-prefixed stream content and numeric statuses are retained
verbatim in those records. Do not present this packaging deviation as separate raw-file evidence.

## Coordinator post-failure audit deviation

After the worker stopped, the Sol coordinator inadvertently issued read-only components that had
been reserved for gate 5 while auditing the tree:

```text
git diff --check
git diff --name-status c1c591239f30b080566ebcd2d7708caaa44a5bbd
git diff --name-status e684275cb349e49a66e73f7f030da6520dd63607
```

They returned a clean diff check, the three-path attempt-3 working diff, and the cumulative #552
plus root-owned amendment/evidence paths respectively. The mandated gate-5 wrapper, fail-fast
path-rejection logic, per-gate pre-state, and evidence files were never created or run, so gate 5
remains **NOT RUN**. This accidental read-only audit did not mutate source or Git state and is not
acceptance evidence. Preserve this disclosure with the attempt record.

## Evidence inventory and identities

- `/tmp/issue552/luna-high-attempt3-prompt.md`
- `/tmp/issue552/luna-high-attempt3.command.json`
  (`3c0edb8e15d596dafa8ee0bf06b12a71d70c79cbd660ea32b31182d8c96c5a70`)
- `/tmp/issue552/luna-high-attempt3.stdout`
  (`bc0aeb3bd906baefda1b61b5cbe6fe8ada96d51a216ca57c622affc9afe97114`)
- `/tmp/issue552/luna-high-attempt3.stderr`
  (`d7fc12b1437dc112f3b3c010e3db92cfcb484c9740f4ef63b1f806768fa3926e`)
- `/tmp/issue552/luna-high-attempt3.status`
  (`9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa`)
- `/tmp/issue552/luna-high-attempt3.md`
  (`a28e330a56863805826bb26b55c3323c88f72b826bac80b589bd64aad2bf3ce5`)
- `/tmp/issue552/attempt3-worker-identity.txt`
- `/tmp/issue552/attempt3-worker-paths.sha256`
- `/tmp/issue552/attempt3-worker-dependencies.txt`
- `/tmp/issue552/attempt3-direct.mjs`
- `/tmp/issue552/attempt3-gate01-{argv,evidence}.txt`
- `/tmp/issue552/attempt3-gate02-{argv,evidence}.txt`
- `/tmp/issue552/attempt3-gate03-{argv,evidence}.txt`
- `/tmp/issue552/attempt3-gate04-{argv,evidence}.txt`

## Boundary

The candidate is not focused-green and receives no Sol HIGH PASS. Attempt 3 is exhausted. #552
retains every original product, provenance, final artifact, browser, workspace, semantic-census,
CI, merge, issue-sync, and CP-20 closure obligation. None may be waived because the defect is
narrow. No further #552 implementation attempt is authorized.
