# Sol HIGH rescope decision after issue #552 attempt 3

**Decision: STOP #552 IMPLEMENTATION AND SPLIT ONE QUALIFICATION SUCCESSOR.**

## Why a successor is justified

Attempt 3 exhausted #552's implementation budget. The frozen product slice and ordinary source
provenance validator now pass their direct vectors, strict SDK type gate, and ordinary complete
stem-store gate. The remaining failure is confined to the newly added opt-in mutation fixture: it
copies the `web/stem-store` directory into a temporary root but omits the sibling
`web/hex-lower.js` required by the record's literal `../hex-lower.js` dependency.

This failure can be separated as qualification tooling because its correction does not require a
new product behavior, helper/API, provenance schema/value, route, package boundary, hash owner, or
source pin. A new stateless issue may repair only the temporary fixture topology and finish the
negative proof. The failed #552 candidate must first be preserved by root and adjudicated by actual
Sol XHIGH. The new issue starts its own workflow only after root numbers and synchronizes it.

This is not permission to make a fourth #552 attempt. Any change to the SDK helper, either browser
helper/adaptor, `incremental-sha256.js`, its provenance JSON, tests, qualification route, digest,
artifact, fixture, expected value, dependency/lock, Rust/Cargo source, or ABI is outside the
successor and must stop for a new product ruling.

## Number-ready successor

Suggested title:

> Repair the stem-store provenance self-test's relative dependency fixture

One-line objective:

> Stage the already-pinned `incremental-sha256.js` and exact sibling `../hex-lower.js` source
> closure in the existing temporary provenance mutation test so all six #552 negative cases execute
> and fail for their intended validator reason.

### Allowed paths

- `.github/ISSUE_SPECS/<number>-repair-stem-store-provenance-self-test-fixture.md`;
- `scripts/check-stem-store-v1.mjs`, limited to the provenance self-test's temporary fixture
  staging/cleanup and assertions;
- issue evidence artifacts.

All ten #552 product/test/provenance paths, including
`hosts/host-web/web/stem-store/incremental-sha256.provenance.json` and `sdk/src/core/hex.ts`, are
read-only. The successor consumes root's candid #552 failed checkpoint as an explicit prerequisite;
it does not claim ownership of those bytes.

### Frozen invariants

1. Keep the production `validateSourceProvenance()` behavior and exact schema/name/hash/string
   checks byte-identical unless actual Sol review finds that a change is unavoidable; such a
   finding requires rescope before implementation.
2. Preserve the existing `--self-test` CLI and all prior ordinary, budget, operator-path, and
   mutation-ledger behavior. Add no new mode or framework.
3. A temporary fixture must reproduce the minimum relevant topology: a stem-store directory
   containing the provenance record and primary source, with `hex-lower.js` at the exact parent
   path selected by `../hex-lower.js`. It may copy only those required files/directories and must
   clean them on PASS or failure.
4. Execute all six already-frozen negative cases: primary bytes, helper bytes, roster removed,
   extra entry, renamed dependency, and different well-formed dependency hash. Each must reach
   `validateSourceProvenance()` and be rejected for its named semantic reason; filesystem setup
   errors do not pass.
5. Never modify the checkout during mutation tests. Never rewrite a pin, digest, fixture, output,
   artifact, PCM identity, or expected product value.
6. No package install/update, dependency/lock change, generated file, benchmark, timed workload,
   generic fixture framework, browser work, Rust/Cargo work, or Git/GitHub mutation by workers.

### Smallest finite implementation gate

Use actual Luna HIGH implementation under Sol HIGH coordination. Before editing, record exact
launcher argv/model/effort, cwd, clean HEAD/status, the checker identity, and read-only identities of
the three provenance-closure files. Run once in order, preserving separate raw stdout/stderr/status
and stopping at the first failure:

1. `node scripts/check-stem-store-v1.mjs --self-test` — this already runs the ordinary complete
   suite before the full existing mutation ledger and must print all six attributable new
   provenance `RED:` records plus every prior mutation proof before PASS.
2. `git diff --check` and exact changed-path rejection proving only
   `scripts/check-stem-store-v1.mjs` changed relative to the root-provided failed checkpoint.

Pause immediately on green for root's exact-path checkpoint and push. Actual Sol XHIGH then reviews
the successor against its own stateless issue and raw evidence. If its attempt fails, follow its own
three-attempt workflow; do not edit #552 product/provenance paths to make the tooling gate pass.

## Relationship to #552 closure

Delivering the successor repairs a required proof but does not close #552 or CP-20. After the
successor is delivered and #543/#555 deliver their exact six-file artifact and Rust census state,
root integrates those prerequisites into the #552 recovery line. #552 must then run every deferred
final gate from its amended issue using root-assigned `DELIVERED_ARTIFACT_DIR`, obtain actual Sol
XHIGH PASS on the combined frozen candidate/evidence, pass required CI, merge, synchronize and
close the matching GitHub issue, and only then update audit #349 CP-20 to delivered.

The historical `/tmp/issue537-delivery/artifact` remains evidence only and is never a final input.
