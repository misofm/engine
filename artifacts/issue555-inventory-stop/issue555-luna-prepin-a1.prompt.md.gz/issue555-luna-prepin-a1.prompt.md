You are Luna HIGH executing issue #555 pre-pin qualification steps 1-4 only. Work autonomously and stop at the first failed acceptance condition. The coordinating Sol and root prohibit all Git/GitHub mutations and all repository edits.

Governing inputs:
- Repository/worktree: /home/bl/misofm/engine-hex-artifact-qualification
- Current evidence/spec descendant HEAD expected: 6243f43160701da60dc067a6b17586bb7dd071d1
- Exact frozen product source: e4f46fa808e413507d204e81b6a4ebc27254869c
- Issue spec: .github/ISSUE_SPECS/555-qualify-shared-hex-web-artifact.md
- Expected candidate Wasm digest (must match exactly or STOP): 6452f0db237da1d57b3594e7d95dd53a089a604d5b0791ea8b3533c5930c5a1c
- Baseline artifact: /tmp/issue537-delivery/artifact
- Existing required-run raw log to retain/reference: /tmp/issue349-partials/543-artifact-job.log

Read AGENTS.md and the complete issue spec first. Execute only finite pre-pin steps 1-4. Do not launch Astra. Do not edit the repository pin or spec. Do not run Git writes of any kind (no worktree/add/commit/branch/reset/checkout) and no gh operations. Treat the repository as read-only. Do not inspect any legacy engine or paused issue #539 source; /tmp/issue539/luna-fresh.py is merely the already-used launcher and is outside your task.

Use fresh, unique, non-overwriting paths under /tmp/issue555-luna-a1 for the evidence/captures, and the issue-specified fresh paths /tmp/issue555-repin-probe-empty, /tmp/issue555-qualified-artifact, /tmp/issue555-native-target, and /tmp/issue555-hermetic-target only after proving they do not already exist. If any exists, STOP rather than overwrite. You may create exact source exports/scratch under /tmp/issue555-luna-a1. Never write generated dependencies/targets into the repository.

Identity/source handling is strict:
1. Verify current HEAD and that the frozen commit exists. Record exact commit/tree/config/toolchain identities and clean status read-only.
2. Export the exact frozen commit e4f46fa808e413507d204e81b6a4ebc27254869c into isolated /tmp scratch using a read-only Git operation such as git archive (exclude .git inherently). Do not silently use current HEAD as product source. Prove a complete sorted file inventory/content digest against the frozen commit/tree before overlay. Also prove the evidence/spec descendant has no product/config changes versus the frozen commit; classify only issue/evidence descendant changes.
3. Run step 1 from a pristine exact-frozen-source export (or equivalently proved exact frozen tree), not from descendant bytes. Create /tmp/issue555-repin-probe-empty as empty non-symlink. Capture exact argv, cwd, relevant environment (including Rust/Cargo variables and tool versions), source IDs, stdout, stderr, numeric status separately without altering streams. Command: env MISO_ENGINE_WEB_AUDIOWORKLET_REPIN=1 bash scripts/build-web-audioworklet.sh /tmp/issue555-repin-probe-empty. Require status 0, stdout exactly the expected 64-hex digest plus newline, stderr retained, and output dir still empty/non-symlink. Any mismatch STOP.
4. As soon as step 1 is verified, write a concise atomic progress report to /tmp/issue555-luna-a1/STEP1_CHECKPOINT.md containing result, digest, status, frozen identity, capture paths. Continue automatically if green.
5. Create a separate exact frozen source scratch for steps 2-4. Before overlay, produce a complete sorted path/type/mode/size/SHA-256 inventory and prove it equals the exact frozen commit export. Apply the sole provisional one-line pin overlay at hosts/host-web/web/miso-engine-v1-audio-worklet-artifact.sha256, changing only the prior pin to the expected candidate digest with final newline. Capture exact before/after bytes, sha256, and a no-index/exact diff. Prove there are no other scratch differences from frozen source.
6. Run unchanged ordinary builder from overlay scratch to /tmp/issue555-qualified-artifact, with exact command capture. Require status 0, exact six files, and independently hash the Wasm to the expected digest. Immediately write /tmp/issue555-luna-a1/ARTIFACT_CHECKPOINT.md with the six-file sorted name/byte-count/SHA-256 manifest, Wasm digest, builder status and capture paths. Continue automatically only if green.
7. Compare every candidate file byte-for-byte and by manifest against /tmp/issue537-delivery/artifact. Preserve both manifests and an explicit per-file equal/different table. Do not explain away deltas; record them for Astra classification. Require exact candidate file names specified by issue #555 and no extras.
8. Execute step 4 gates in the exact listed order, from the overlay scratch where applicable, capturing for every command exact argv, cwd, selected environment/source IDs, stdout, stderr and numeric status in unique files. Stop at first nonzero or semantic gate failure; preserve everything already produced. Commands are exactly:
   env CARGO_TARGET_DIR=/tmp/issue555-native-target bash scripts/check-capi-abi.sh .
   bash scripts/check-web-audioworklet.sh /tmp/issue555-qualified-artifact
   env CARGO_TARGET_DIR=/tmp/issue555-native-target python3 -B scripts/check-browser-expected-resources.py --artifacts /tmp/issue555-qualified-artifact
   env CARGO_TARGET_DIR=/tmp/issue555-hermetic-target bash scripts/test-web-audioworklet.sh
   npm --prefix hosts/host-web/qualification ci --ignore-scripts
   npm --prefix hosts/host-web/qualification run qualify -- --artifacts /tmp/issue555-qualified-artifact --browser all --check-matrix --self-test-mutations
Do not add gate frameworks, benchmarks, retries, repairs, expectation updates, or --record-matrix. For the browser gate require actual Chromium, Firefox and WebKit selection/execution and zero skipped browser selection; a zero status with zero/skipped selection is failure.
9. Prove committed expected.json, results.json, BROWSER_DEPLOYMENT_MATRIX.md and all frozen repository bytes remain unchanged. Ensure no repository mutation occurred. Retain/copy the two failure facts/raw evidence from required run 34108626421/job 101699476520 without modifying original evidence.

Capture exact raw streams; do not normalize or truncate. Use wrappers that preserve true exit status. Do not rerun a failed command. Do not use the repin environment after step 1. Do not pin anything in the repository. Do not perform Sol implementation. Finish with a concise PASS/FAIL report giving first failure if any, all capture paths, manifest/delta summary, gate statuses, browser selection/skips, and explicit readiness for root checkpoint/Astra MEDIUM. Pre-pin PASS is only possible if every step 1-4 criterion is green.
